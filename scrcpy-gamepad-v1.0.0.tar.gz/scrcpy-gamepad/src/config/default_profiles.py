"""
Default game profiles for common game types.
"""

from typing import Dict, Any, Optional


PROFILE_FPS: Dict[str, Any] = {
    "name": "FPS (PUBG/COD Mobile)",
    "description": "First-person shooter layout with WASD movement, mouse aim, and combat keys",
    "version": "1.0",
    "game_type": "fps",
    "mappings": {
        "W": {
            "action": "joystick",
            "direction": "up",
            "group": "movement",
            "params": {
                "center_x": 0.15,
                "center_y": 0.7,
                "radius": 0.08
            }
        },
        "A": {
            "action": "joystick",
            "direction": "left",
            "group": "movement",
            "params": {
                "center_x": 0.15,
                "center_y": 0.7,
                "radius": 0.08
            }
        },
        "S": {
            "action": "joystick",
            "direction": "down",
            "group": "movement",
            "params": {
                "center_x": 0.15,
                "center_y": 0.7,
                "radius": 0.08
            }
        },
        "D": {
            "action": "joystick",
            "direction": "right",
            "group": "movement",
            "params": {
                "center_x": 0.15,
                "center_y": 0.7,
                "radius": 0.08
            }
        },
        "Space": {
            "action": "tap",
            "params": {
                "x": 0.85,
                "y": 0.75,
                "coordinate_mode": "normalized"
            },
            "description": "Jump"
        },
        "R": {
            "action": "tap",
            "params": {
                "x": 0.9,
                "y": 0.65,
                "coordinate_mode": "normalized"
            },
            "description": "Reload"
        },
        "E": {
            "action": "tap",
            "params": {
                "x": 0.85,
                "y": 0.6,
                "coordinate_mode": "normalized"
            },
            "description": "Interact"
        },
        "F": {
            "action": "tap",
            "params": {
                "x": 0.9,
                "y": 0.85,
                "coordinate_mode": "normalized"
            },
            "description": "Crouch"
        },
        "G": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.5,
                "coordinate_mode": "normalized"
            },
            "description": "Grenade"
        },
        "Q": {
            "action": "tap",
            "params": {
                "x": 0.8,
                "y": 0.55,
                "coordinate_mode": "normalized"
            },
            "description": "Lean Left"
        },
        "C": {
            "action": "tap",
            "params": {
                "x": 0.75,
                "y": 0.85,
                "coordinate_mode": "normalized"
            },
            "description": "Prone"
        },
        "Z": {
            "action": "tap",
            "params": {
                "x": 0.75,
                "y": 0.9,
                "coordinate_mode": "normalized"
            },
            "description": "Scope"
        },
        "1": {
            "action": "tap",
            "params": {
                "x": 0.65,
                "y": 0.9,
                "coordinate_mode": "normalized"
            },
            "description": "Weapon 1"
        },
        "2": {
            "action": "tap",
            "params": {
                "x": 0.7,
                "y": 0.9,
                "coordinate_mode": "normalized"
            },
            "description": "Weapon 2"
        },
        "MouseLeft": {
            "action": "tap",
            "params": {
                "x": 0.85,
                "y": 0.5,
                "coordinate_mode": "normalized"
            },
            "description": "Fire"
        },
        "MouseRight": {
            "action": "long_press",
            "params": {
                "x": 0.5,
                "y": 0.5,
                "duration_ms": 100,
                "coordinate_mode": "normalized"
            },
            "description": "Aim/Scope"
        },
        "Tab": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.05,
                "coordinate_mode": "normalized"
            },
            "description": "Inventory"
        },
        "M": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.08,
                "coordinate_mode": "normalized"
            },
            "description": "Map"
        }
    },
    "joystick": {
        "enabled": True,
        "center_x": 0.15,
        "center_y": 0.7,
        "radius": 0.08,
        "dead_zone": 0.15
    },
    "mouse": {
        "enabled": True,
        "aim_x": 0.5,
        "aim_y": 0.5,
        "sensitivity": 1.0
    }
}

PROFILE_MOBA: Dict[str, Any] = {
    "name": "MOBA (Mobile Legends/Wild Rift)",
    "description": "MOBA layout with joystick movement and skill buttons",
    "version": "1.0",
    "game_type": "moba",
    "mappings": {
        "W": {
            "action": "joystick",
            "direction": "up",
            "group": "movement",
            "params": {
                "center_x": 0.12,
                "center_y": 0.65,
                "radius": 0.08
            }
        },
        "A": {
            "action": "joystick",
            "direction": "left",
            "group": "movement",
            "params": {
                "center_x": 0.12,
                "center_y": 0.65,
                "radius": 0.08
            }
        },
        "S": {
            "action": "joystick",
            "direction": "down",
            "group": "movement",
            "params": {
                "center_x": 0.12,
                "center_y": 0.65,
                "radius": 0.08
            }
        },
        "D": {
            "action": "joystick",
            "direction": "right",
            "group": "movement",
            "params": {
                "center_x": 0.12,
                "center_y": 0.65,
                "radius": 0.08
            }
        },
        "Q": {
            "action": "tap",
            "params": {
                "x": 0.82,
                "y": 0.7,
                "coordinate_mode": "normalized"
            },
            "description": "Skill 1"
        },
        "W_Skill": {
            "action": "tap",
            "params": {
                "x": 0.88,
                "y": 0.55,
                "coordinate_mode": "normalized"
            },
            "description": "Skill 2",
            "key": "E"
        },
        "E": {
            "action": "tap",
            "params": {
                "x": 0.92,
                "y": 0.65,
                "coordinate_mode": "normalized"
            },
            "description": "Skill 3"
        },
        "R": {
            "action": "tap",
            "params": {
                "x": 0.88,
                "y": 0.45,
                "coordinate_mode": "normalized"
            },
            "description": "Ultimate"
        },
        "Space": {
            "action": "tap",
            "params": {
                "x": 0.95,
                "y": 0.8,
                "coordinate_mode": "normalized"
            },
            "description": "Basic Attack"
        },
        "D_Flash": {
            "action": "tap",
            "params": {
                "x": 0.95,
                "y": 0.9,
                "coordinate_mode": "normalized"
            },
            "description": "Flash",
            "key": "F"
        },
        "B": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.95,
                "coordinate_mode": "normalized"
            },
            "description": "Recall"
        },
        "Tab": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.05,
                "coordinate_mode": "normalized"
            },
            "description": "Scoreboard"
        },
        "MouseLeft": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.5,
                "coordinate_mode": "normalized"
            },
            "description": "Move/Aim"
        }
    },
    "joystick": {
        "enabled": True,
        "center_x": 0.12,
        "center_y": 0.65,
        "radius": 0.08,
        "dead_zone": 0.12
    },
    "mouse": {
        "enabled": False
    }
}

PROFILE_RACING: Dict[str, Any] = {
    "name": "Racing (Asphalt/Mario Kart)",
    "description": "Racing layout with tilt/steering and acceleration controls",
    "version": "1.0",
    "game_type": "racing",
    "mappings": {
        "W": {
            "action": "tap",
            "params": {
                "x": 0.85,
                "y": 0.7,
                "coordinate_mode": "normalized"
            },
            "description": "Accelerate"
        },
        "S": {
            "action": "tap",
            "params": {
                "x": 0.85,
                "y": 0.85,
                "coordinate_mode": "normalized"
            },
            "description": "Brake"
        },
        "A": {
            "action": "swipe",
            "params": {
                "x1": 0.3,
                "y1": 0.5,
                "x2": 0.1,
                "y2": 0.5,
                "duration_ms": 200,
                "coordinate_mode": "normalized"
            },
            "description": "Steer Left"
        },
        "D": {
            "action": "swipe",
            "params": {
                "x1": 0.3,
                "y1": 0.5,
                "x2": 0.5,
                "y2": 0.5,
                "duration_ms": 200,
                "coordinate_mode": "normalized"
            },
            "description": "Steer Right"
        },
        "Space": {
            "action": "tap",
            "params": {
                "x": 0.9,
                "y": 0.75,
                "coordinate_mode": "normalized"
            },
            "description": "Nitro"
        },
        "E": {
            "action": "tap",
            "params": {
                "x": 0.9,
                "y": 0.6,
                "coordinate_mode": "normalized"
            },
            "description": "Item/Power-up"
        },
        "F": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.5,
                "coordinate_mode": "normalized"
            },
            "description": "Drift"
        },
        "MouseLeft": {
            "action": "tap",
            "params": {
                "x": 0.5,
                "y": 0.5,
                "coordinate_mode": "normalized"
            },
            "description": "Touch Point"
        }
    },
    "joystick": {
        "enabled": False
    },
    "mouse": {
        "enabled": False
    }
}

_ALL_PROFILES: Dict[str, Dict[str, Any]] = {
    "FPS": PROFILE_FPS,
    "MOBA": PROFILE_MOBA,
    "Racing": PROFILE_RACING,
}


def get_all_profiles() -> Dict[str, Dict[str, Any]]:
    """Return all available profiles."""
    return dict(_ALL_PROFILES)


def get_profile(name: str) -> Optional[Dict[str, Any]]:
    """Get a single profile by name. Returns None if not found."""
    return _ALL_PROFILES.get(name)


def get_profile_names() -> list:
    """Return list of available profile names."""
    return list(_ALL_PROFILES.keys())
