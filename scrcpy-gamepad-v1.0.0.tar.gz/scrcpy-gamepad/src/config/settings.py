"""
Application settings manager for scrcpy-gamepad.
Singleton pattern with JSON persistence.
"""

import json
import os
import threading
from pathlib import Path


class Settings:
    """Application-wide settings with persistence."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        self._config_dir = Path.home() / ".scrcpy-gamepad"
        self._config_file = self._config_dir / "settings.json"
        self._lock_file = threading.Lock()

        # Paths
        self.adb_path: str = "adb"
        self.scrcpy_path: str = "scrcpy"

        # Display
        self.default_resolution: int = 720
        self.refresh_rate: int = 60
        self.bit_rate: int = 8000000

        # Input
        self.key_repeat_rate: float = 0.05  # seconds between repeats
        self.dead_zone_size: float = 0.15   # normalized 0-1
        self.joystick_sensitivity: float = 1.0
        self.mouse_sensitivity: float = 1.0

        # Overlay
        self.overlay_opacity: float = 0.6
        self.overlay_color_tap: str = "#00FF88"
        self.overlay_color_swipe: str = "#FF6600"
        self.overlay_color_joystick: str = "#00AAFF"
        self.overlay_color_long_press: str = "#FF00AA"

        # Joystick
        self.joystick_update_rate: int = 60  # Hz
        self.joystick_center_x: float = 0.15  # normalized
        self.joystick_center_y: float = 0.7   # normalized
        self.joystick_radius: float = 0.08     # normalized

        # Window
        self.window_width: int = 1200
        self.window_height: int = 800
        self.window_x: int = -1
        self.window_y: int = -1

        # Last connection
        self.last_device_ip: str = ""
        self.last_device_serial: str = ""
        self.last_profile: str = ""

        # Advanced
        self.sendevent_device: str = "/dev/input/event2"
        self.use_sendevent: bool = True
        self.batch_commands: bool = True
        self.command_timeout: float = 5.0

        self._load()

    def _load(self):
        """Load settings from JSON file."""
        try:
            if self._config_file.exists():
                with open(self._config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for key, value in data.items():
                    if hasattr(self, key):
                        setattr(self, key, value)
        except (json.JSONDecodeError, OSError):
            pass  # Use defaults on error

    def save(self):
        """Save current settings to JSON file."""
        with self._lock_file:
            try:
                self._config_dir.mkdir(parents=True, exist_ok=True)
                data = {}
                for key, value in self.__dict__.items():
                    if not key.startswith("_") and not callable(value):
                        data[key] = value
                with open(self._config_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except OSError:
                pass

    def reset_to_defaults(self):
        """Reset all settings to defaults and save."""
        defaults = Settings.__new__(Settings)
        defaults.__init__()
        for key, value in defaults.__dict__.items():
            if not key.startswith("_"):
                setattr(self, key, value)
        self.save()

    def get(self, key: str, default=None):
        """Get a setting value by key."""
        return getattr(self, key, default)

    def set(self, key: str, value):
        """Set a setting value by key."""
        setattr(self, key, value)
