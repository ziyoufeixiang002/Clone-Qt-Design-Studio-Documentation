"""
Key mapping engine for scrcpy-gamepad.
Maps keyboard/mouse inputs to touch actions.
"""

import json
import logging
import threading
import time
from enum import Enum
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List, Tuple
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


class MappingAction(Enum):
    """Types of mapping actions."""
    TAP = "tap"
    SWIPE = "swipe"
    JOYSTICK = "joystick"
    LONG_PRESS = "long_press"
    MULTI_TAP = "multi_tap"
    COMBO = "combo"


@dataclass
class KeyMapping:
    """Represents a single key-to-action mapping."""
    key: str
    action: MappingAction
    params: Dict[str, Any] = field(default_factory=dict)
    description: str = ""
    group: str = ""
    enabled: bool = True
    modifier: Optional[str] = None  # e.g., "Shift", "Ctrl", "Alt"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "action": self.action.value,
            "params": self.params,
            "description": self.description,
            "group": self.group,
            "enabled": self.enabled,
            "modifier": self.modifier,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KeyMapping":
        return cls(
            key=data["key"],
            action=MappingAction(data["action"]),
            params=data.get("params", {}),
            description=data.get("description", ""),
            group=data.get("group", ""),
            enabled=data.get("enabled", True),
            modifier=data.get("modifier"),
        )


class KeyMapper:
    """
    Core key mapping engine.
    Processes keyboard events and triggers corresponding touch actions.
    """

    def __init__(self):
        self._mappings: Dict[str, KeyMapping] = {}
        self._lock = threading.Lock()
        self._pressed_keys: set = set()
        self._active_modifiers: set = set()
        self._action_handlers: Dict[MappingAction, Callable] = {}
        self._joystick_keys: Dict[str, Dict[str, Any]] = {}  # WASD joystick config
        self._mouse_mappings: Dict[str, KeyMapping] = {}
        self._key_states: Dict[str, bool] = {}  # key -> is_pressed
        self._repeat_timers: Dict[str, threading.Timer] = {}
        self._repeat_rate: float = 0.05  # seconds
        self._modifier_keys = {"Shift", "Ctrl", "Alt", "Meta", "Shift_L", "Shift_R",
                                "Ctrl_L", "Ctrl_R", "Alt_L", "Alt_R"}
        self._on_mapping_changed: Optional[Callable] = None

    @property
    def mappings(self) -> Dict[str, KeyMapping]:
        return dict(self._mappings)

    def set_action_handler(self, action: MappingAction, handler: Callable):
        """Register a handler for a specific action type."""
        self._action_handlers[action] = handler

    def set_on_mapping_changed(self, callback: Callable):
        """Register callback when mappings change."""
        self._on_mapping_changed = callback

    def add_mapping(self, key: str, action: MappingAction, params: Dict[str, Any],
                    description: str = "", group: str = "", modifier: Optional[str] = None) -> KeyMapping:
        """Add or update a key mapping."""
        with self._lock:
            mapping = KeyMapping(
                key=key,
                action=action,
                params=params,
                description=description,
                group=group,
                modifier=modifier,
            )

            # Build the lookup key
            lookup_key = self._make_lookup_key(key, modifier)
            self._mappings[lookup_key] = mapping

            # Track joystick keys specially
            if action == MappingAction.JOYSTICK:
                self._joystick_keys[lookup_key] = params

            # Track mouse mappings
            if key.startswith("Mouse"):
                self._mouse_mappings[lookup_key] = mapping

            logger.info(f"Added mapping: {lookup_key} -> {action.value}")
            if self._on_mapping_changed:
                self._on_mapping_changed()
            return mapping

    def remove_mapping(self, key: str, modifier: Optional[str] = None):
        """Remove a key mapping."""
        with self._lock:
            lookup_key = self._make_lookup_key(key, modifier)
            removed = self._mappings.pop(lookup_key, None)
            self._joystick_keys.pop(lookup_key, None)
            self._mouse_mappings.pop(lookup_key, None)
            if removed and self._on_mapping_changed:
                self._on_mapping_changed()

    def _make_lookup_key(self, key: str, modifier: Optional[str] = None) -> str:
        """Create a lookup key from key + optional modifier."""
        if modifier:
            return f"{modifier}+{key}"
        return key

    def process_key_event(self, key_code: str, is_pressed: bool) -> Optional[Dict[str, Any]]:
        """
        Process a keyboard event.
        Returns the action dict if a mapping was triggered, None otherwise.
        """
        with self._lock:
            # Track modifier state
            if key_code in self._modifier_keys:
                if is_pressed:
                    self._active_modifiers.add(key_code)
                else:
                    self._active_modifiers.discard(key_code)
                return None

            # Build lookup key with active modifiers
            modifier = self._get_active_modifier()
            lookup_key = self._make_lookup_key(key_code, modifier)

            # Update key state
            self._key_states[key_code] = is_pressed

            # Try exact match first (with modifier)
            mapping = self._mappings.get(lookup_key)
            if mapping is None:
                # Try without modifier
                mapping = self._mappings.get(key_code)
                if mapping is None:
                    return None

            if not mapping.enabled:
                return None

            # Handle based on action type
            if mapping.action == MappingAction.TAP:
                if is_pressed:
                    self._execute_action(mapping)
                    return {"action": "tap", "mapping": mapping.to_dict()}
                return None

            elif mapping.action == MappingAction.LONG_PRESS:
                if is_pressed:
                    self._start_long_press(mapping)
                else:
                    self._cancel_long_press(key_code)
                return {"action": "long_press", "pressed": is_pressed, "mapping": mapping.to_dict()}

            elif mapping.action == MappingAction.SWIPE:
                if is_pressed:
                    self._execute_action(mapping)
                    return {"action": "swipe", "mapping": mapping.to_dict()}
                return None

            elif mapping.action == MappingAction.JOYSTICK:
                return {"action": "joystick", "key": key_code, "pressed": is_pressed,
                        "mapping": mapping.to_dict()}

            elif mapping.action == MappingAction.MULTI_TAP:
                if is_pressed:
                    self._execute_action(mapping)
                    return {"action": "multi_tap", "mapping": mapping.to_dict()}
                return None

            elif mapping.action == MappingAction.COMBO:
                if is_pressed:
                    self._execute_combo(mapping)
                    return {"action": "combo", "mapping": mapping.to_dict()}
                return None

        return None

    def process_mouse_event(self, button: str, is_pressed: bool, x: float = 0, y: float = 0) -> Optional[Dict[str, Any]]:
        """Process a mouse button event."""
        key = f"Mouse{button}"
        mapping = self._mouse_mappings.get(key) or self._mappings.get(key)
        if mapping and mapping.enabled and is_pressed:
            # Update coordinates if mapping uses mouse position
            params = dict(mapping.params)
            if params.get("use_mouse_position", False):
                params["x"] = x
                params["y"] = y
            temp_mapping = KeyMapping(
                key=mapping.key,
                action=mapping.action,
                params=params,
                description=mapping.description,
            )
            self._execute_action(temp_mapping)
            return {"action": mapping.action.value, "mapping": mapping.to_dict()}
        return None

    def _get_active_modifier(self) -> Optional[str]:
        """Get the current active modifier key."""
        if not self._active_modifiers:
            return None
        # Return the first active modifier
        for mod in ["Shift", "Ctrl", "Alt", "Meta"]:
            if mod in self._active_modifiers or f"{mod}_L" in self._active_modifiers:
                return mod
        return None

    def _execute_action(self, mapping: KeyMapping):
        """Execute a mapping action by calling the registered handler."""
        handler = self._action_handlers.get(mapping.action)
        if handler:
            try:
                handler(mapping)
            except Exception as e:
                logger.error(f"Action handler error for {mapping.key}: {e}")
        else:
            logger.warning(f"No handler for action type: {mapping.action}")

    def _start_long_press(self, mapping: KeyMapping):
        """Start a long press timer."""
        key = mapping.key
        self._cancel_long_press(key)

        def on_timeout():
            self._execute_action(mapping)

        timer = threading.Timer(
            mapping.params.get("delay", 0.3),
            on_timeout
        )
        timer.daemon = True
        self._repeat_timers[key] = timer
        timer.start()

    def _cancel_long_press(self, key: str):
        """Cancel a pending long press."""
        timer = self._repeat_timers.pop(key, None)
        if timer:
            timer.cancel()

    def _execute_combo(self, mapping: KeyMapping):
        """Execute a combo action (sequence of taps)."""
        actions = mapping.params.get("actions", [])
        for action in actions:
            action_type = action.get("action")
            if action_type == "tap":
                handler = self._action_handlers.get(MappingAction.TAP)
                if handler:
                    temp = KeyMapping(
                        key="combo_step",
                        action=MappingAction.TAP,
                        params=action.get("params", {}),
                    )
                    handler(temp)
                    time.sleep(action.get("delay", 0.05) / 1000.0)

    def get_joystick_config(self) -> Dict[str, Dict[str, Any]]:
        """Get all joystick mapping configurations."""
        return dict(self._joystick_keys)

    def load_profile(self, path: str):
        """Load key mappings from a JSON profile file."""
        with self._lock:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                self._mappings.clear()
                self._joystick_keys.clear()
                self._mouse_mappings.clear()

                mappings_data = data.get("mappings", {})
                for key_str, mapping_data in mappings_data.items():
                    mapping = KeyMapping.from_dict(mapping_data)
                    lookup_key = self._make_lookup_key(mapping.key, mapping.modifier)
                    self._mappings[lookup_key] = mapping

                    if mapping.action == MappingAction.JOYSTICK:
                        self._joystick_keys[lookup_key] = mapping.params
                    if mapping.key.startswith("Mouse"):
                        self._mouse_mappings[lookup_key] = mapping

                logger.info(f"Loaded profile from {path}: {len(self._mappings)} mappings")
                if self._on_mapping_changed:
                    self._on_mapping_changed()

            except (json.JSONDecodeError, OSError) as e:
                logger.error(f"Failed to load profile {path}: {e}")

    def save_profile(self, path: str, metadata: Optional[Dict[str, Any]] = None):
        """Save current mappings to a JSON profile file."""
        with self._lock:
            try:
                data = {
                    "version": "1.0",
                    "metadata": metadata or {},
                    "mappings": {}
                }
                for key_str, mapping in self._mappings.items():
                    data["mappings"][key_str] = mapping.to_dict()

                Path(path).parent.mkdir(parents=True, exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                logger.info(f"Saved profile to {path}")

            except OSError as e:
                logger.error(f"Failed to save profile {path}: {e}")

    def load_from_dict(self, profile: Dict[str, Any]):
        """Load mappings from a profile dictionary."""
        with self._lock:
            self._mappings.clear()
            self._joystick_keys.clear()
            self._mouse_mappings.clear()

            mappings_data = profile.get("mappings", {})
            for key_str, mapping_data in mappings_data.items():
                if isinstance(mapping_data, dict):
                    # Handle both raw params and full mapping format
                    if "action" in mapping_data:
                        action = MappingAction(mapping_data["action"])
                        params = mapping_data.get("params", {})
                        desc = mapping_data.get("description", "")
                        group = mapping_data.get("group", "")
                    else:
                        # Legacy format: key -> {x, y, ...}
                        action = MappingAction.TAP
                        params = mapping_data
                        desc = ""
                        group = ""

                    # Get the actual key to bind
                    actual_key = mapping_data.get("key", key_str)
                    modifier = mapping_data.get("modifier")

                    mapping = KeyMapping(
                        key=actual_key,
                        action=action,
                        params=params,
                        description=desc,
                        group=group,
                        modifier=modifier,
                    )
                    lookup_key = self._make_lookup_key(actual_key, modifier)
                    self._mappings[lookup_key] = mapping

                    if action == MappingAction.JOYSTICK:
                        self._joystick_keys[lookup_key] = params
                    if actual_key.startswith("Mouse"):
                        self._mouse_mappings[lookup_key] = mapping

            # Load joystick config
            joystick_config = profile.get("joystick", {})
            if joystick_config.get("enabled"):
                # Create joystick mappings for WASD
                center_x = joystick_config.get("center_x", 0.15)
                center_y = joystick_config.get("center_y", 0.7)
                radius = joystick_config.get("radius", 0.08)
                for direction_key in ["W", "A", "S", "D"]:
                    lookup = self._make_lookup_key(direction_key, None)
                    if lookup not in self._mappings:
                        mapping = KeyMapping(
                            key=direction_key,
                            action=MappingAction.JOYSTICK,
                            params={
                                "center_x": center_x,
                                "center_y": center_y,
                                "radius": radius,
                                "direction": {"W": "up", "A": "left", "S": "down", "D": "right"}[direction_key]
                            },
                            group="movement",
                        )
                        self._mappings[lookup] = mapping
                        self._joystick_keys[lookup] = mapping.params

            logger.info(f"Loaded profile from dict: {len(self._mappings)} mappings")
            if self._on_mapping_changed:
                self._on_mapping_changed()

    def get_mapping_list(self) -> List[KeyMapping]:
        """Get all mappings as a sorted list."""
        with self._lock:
            return sorted(self._mappings.values(), key=lambda m: (m.group, m.key))

    def clear_all(self):
        """Remove all mappings."""
        with self._lock:
            self._mappings.clear()
            self._joystick_keys.clear()
            self._mouse_mappings.clear()
            if self._on_mapping_changed:
                self._on_mapping_changed()

    def set_repeat_rate(self, rate: float):
        """Set the key repeat rate in seconds."""
        self._repeat_rate = rate
