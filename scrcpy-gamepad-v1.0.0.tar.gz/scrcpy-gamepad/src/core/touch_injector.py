"""
Touch event injection engine for scrcpy-gamepad.
Wraps ADBManager with higher-level touch operations.
"""

import math
import threading
import time
import logging
from typing import Optional, Tuple, List
from collections import deque

from .adb_manager import ADBManager

logger = logging.getLogger(__name__)


class TouchInjector:
    """High-level touch event injector with coordinate normalization and batching."""

    def __init__(self, adb: ADBManager, use_sendevent: bool = True):
        self._adb = adb
        self._use_sendevent = use_sendevent
        self._lock = threading.Lock()
        self._event_queue = deque(maxlen=1000)
        self._batch_thread: Optional[threading.Thread] = None
        self._batch_running = False
        self._batch_interval = 0.008  # ~120Hz batching
        self._resolution: Optional[Tuple[int, int]] = None
        self._active_pointers: dict = {}  # pointer_id -> (x, y)
        self._debounce_timers: dict = {}
        self._debounce_delay = 0.016  # ~60fps debounce

    def _ensure_resolution(self):
        """Cache device resolution for coordinate normalization."""
        if self._resolution is None:
            self._resolution = self._adb.get_device_resolution()
            if self._resolution is None:
                self._resolution = (1080, 2400)  # Safe default
                logger.warning("Using default resolution 1080x2400")

    def normalize_x(self, x: float) -> int:
        """Convert normalized (0-1) or percentage x to pixel coordinate."""
        self._ensure_resolution()
        if 0 <= x <= 1:
            return int(x * self._resolution[0])
        elif 1 < x <= 100:
            return int((x / 100.0) * self._resolution[0])
        return int(x)

    def normalize_y(self, y: float) -> int:
        """Convert normalized (0-1) or percentage y to pixel coordinate."""
        self._ensure_resolution()
        if 0 <= y <= 1:
            return int(y * self._resolution[1])
        elif 1 < y <= 100:
            return int((y / 100.0) * self._resolution[1])
        return int(y)

    def normalize_coords(self, x: float, y: float) -> Tuple[int, int]:
        """Normalize coordinates to pixel values."""
        return self.normalize_x(x), self.normalize_y(y)

    def inject_tap(self, x: float, y: float, pointer_id: int = 0) -> bool:
        """Inject a tap at coordinates (normalized or absolute)."""
        px, py = self.normalize_coords(x, y)
        if self._use_sendevent:
            return self._sendevent_tap(px, py, pointer_id)
        return self._adb.send_tap(px, py)

    def _sendevent_tap(self, x: int, y: int, pointer_id: int = 0) -> bool:
        """Send a tap using sendevent for lower latency."""
        device = self._adb.touch_device
        events = [
            (3, 57, pointer_id + 100),  # ABS_MT_TRACKING_ID
            (3, 53, x),                 # ABS_MT_POSITION_X
            (3, 54, y),                 # ABS_MT_POSITION_Y
            (3, 48, 50),                # ABS_MT_TOUCH_MAJOR
            (0, 2, 0),                  # SYN_MT_REPORT
            (0, 0, 0),                  # SYN_REPORT (down)

            (3, 57, -1),                # ABS_MT_TRACKING_ID (release)
            (0, 2, 0),                  # SYN_MT_REPORT
            (0, 0, 0),                  # SYN_REPORT (up)
        ]
        return self._adb.send_sendevent_batch(device, events)

    def inject_swipe(self, x1: float, y1: float, x2: float, y2: float,
                     duration_ms: int = 300, pointer_id: int = 0) -> bool:
        """Inject a swipe gesture between two points."""
        px1, py1 = self.normalize_coords(x1, y1)
        px2, py2 = self.normalize_coords(x2, y2)

        if self._use_sendevent:
            return self._sendevent_swipe(px1, py1, px2, py2, duration_ms, pointer_id)
        return self._adb.send_swipe(px1, py1, px2, py2, duration_ms)

    def _sendevent_swipe(self, x1: int, y1: int, x2: int, y2: int,
                         duration_ms: int, pointer_id: int = 0) -> bool:
        """Send a swipe using sendevent with interpolated moves."""
        device = self._adb.touch_device
        steps = max(5, duration_ms // 16)  # ~60 steps per second
        events = []

        # Touch down at start
        events.extend([
            (3, 57, pointer_id + 100),  # ABS_MT_TRACKING_ID
            (3, 53, x1),                # ABS_MT_POSITION_X
            (3, 54, y1),                # ABS_MT_POSITION_Y
            (3, 48, 50),                # ABS_MT_TOUCH_MAJOR
            (0, 2, 0),                  # SYN_MT_REPORT
            (0, 0, 0),                  # SYN_REPORT
        ])

        # Send batch command, then do interpolated moves separately
        # because batching all steps in one command would be too large
        if not self._adb.send_sendevent_batch(device, events):
            return False

        # Interpolate moves
        for i in range(1, steps + 1):
            t = i / steps
            mx = int(x1 + (x2 - x1) * t)
            my = int(y1 + (y2 - y1) * t)
            move_events = [
                (3, 53, mx),   # ABS_MT_POSITION_X
                (3, 54, my),   # ABS_MT_POSITION_Y
                (0, 2, 0),     # SYN_MT_REPORT
                (0, 0, 0),     # SYN_REPORT
            ]
            self._adb.send_sendevent_batch(device, move_events)
            time.sleep(duration_ms / (1000.0 * steps))

        # Release
        release_events = [
            (3, 57, -1),    # ABS_MT_TRACKING_ID (release)
            (0, 2, 0),      # SYN_MT_REPORT
            (0, 0, 0),      # SYN_REPORT
        ]
        return self._adb.send_sendevent_batch(device, release_events)

    def inject_long_press(self, x: float, y: float, duration_ms: int = 500,
                          pointer_id: int = 0) -> bool:
        """Inject a long press at coordinates."""
        px, py = self.normalize_coords(x, y)
        if self._use_sendevent:
            return self._sendevent_long_press(px, py, duration_ms, pointer_id)
        return self._adb.send_long_press(px, py, duration_ms)

    def _sendevent_long_press(self, x: int, y: int, duration_ms: int,
                              pointer_id: int = 0) -> bool:
        """Send a long press using sendevent."""
        device = self._adb.touch_device

        # Touch down
        down_events = [
            (3, 57, pointer_id + 100),  # ABS_MT_TRACKING_ID
            (3, 53, x),                 # ABS_MT_POSITION_X
            (3, 54, y),                 # ABS_MT_POSITION_Y
            (3, 48, 50),                # ABS_MT_TOUCH_MAJOR
            (0, 2, 0),                  # SYN_MT_REPORT
            (0, 0, 0),                  # SYN_REPORT
        ]
        if not self._adb.send_sendevent_batch(device, down_events):
            return False

        # Hold
        time.sleep(duration_ms / 1000.0)

        # Release
        up_events = [
            (3, 57, -1),    # ABS_MT_TRACKING_ID (release)
            (0, 2, 0),      # SYN_MT_REPORT
            (0, 0, 0),      # SYN_REPORT
        ]
        return self._adb.send_sendevent_batch(device, up_events)

    def inject_pinch(self, center_x: float, center_y: float,
                     distance_start: float, distance_end: float,
                     duration_ms: int = 300) -> bool:
        """
        Inject a pinch zoom gesture.
        center_x, center_y: center of the pinch (normalized)
        distance_start: initial distance between fingers (normalized)
        distance_end: final distance between fingers (normalized)
        """
        cx, cy = self.normalize_coords(center_x, center_y)
        ds = self.normalize_x(distance_start) if distance_start <= 1 else int(distance_start)
        de = self.normalize_x(distance_end) if distance_end <= 1 else int(distance_end)

        device = self._adb.touch_device
        steps = max(5, duration_ms // 16)

        # Calculate start and end positions for two fingers
        # Finger 1: top-left to bottom-right
        # Finger 2: bottom-right to top-left
        half_ds = ds // 2
        half_de = de // 2

        # Touch down both fingers
        down_events = [
            # Finger 1
            (3, 57, 100),               # ABS_MT_TRACKING_ID
            (3, 53, cx - half_ds),       # ABS_MT_POSITION_X
            (3, 54, cy - half_ds),       # ABS_MT_POSITION_Y
            (3, 48, 50),                 # ABS_MT_TOUCH_MAJOR
            (0, 2, 0),                   # SYN_MT_REPORT
            # Finger 2
            (3, 57, 101),               # ABS_MT_TRACKING_ID
            (3, 53, cx + half_ds),       # ABS_MT_POSITION_X
            (3, 54, cy + half_ds),       # ABS_MT_POSITION_Y
            (3, 48, 50),                 # ABS_MT_TOUCH_MAJOR
            (0, 2, 0),                   # SYN_MT_REPORT
            (0, 0, 0),                   # SYN_REPORT
        ]
        if not self._adb.send_sendevent_batch(device, down_events):
            return False

        # Interpolate pinch movement
        for i in range(1, steps + 1):
            t = i / steps
            half_d = int(half_ds + (half_de - half_ds) * t)
            move_events = [
                # Finger 1
                (3, 57, 100),
                (3, 53, cx - half_d),
                (3, 54, cy - half_d),
                (3, 48, 50),
                (0, 2, 0),
                # Finger 2
                (3, 57, 101),
                (3, 53, cx + half_d),
                (3, 54, cy + half_d),
                (3, 48, 50),
                (0, 2, 0),
                (0, 0, 0),
            ]
            self._adb.send_sendevent_batch(device, move_events)
            time.sleep(duration_ms / (1000.0 * steps))

        # Release both fingers
        up_events = [
            (3, 57, -1),
            (0, 2, 0),
            (3, 57, -1),
            (0, 2, 0),
            (0, 0, 0),
        ]
        return self._adb.send_sendevent_batch(device, up_events)

    def inject_multi_tap(self, points: List[Tuple[float, float]]) -> bool:
        """
        Inject simultaneous multi-point taps.
        points: list of (x, y) in normalized coordinates
        """
        pixel_points = [self.normalize_coords(x, y) for x, y in points]
        device = self._adb.touch_device
        events = []

        # All fingers down
        for idx, (x, y) in enumerate(pixel_points):
            events.extend([
                (3, 57, idx + 100),  # ABS_MT_TRACKING_ID
                (3, 53, x),          # ABS_MT_POSITION_X
                (3, 54, y),          # ABS_MT_POSITION_Y
                (3, 48, 50),         # ABS_MT_TOUCH_MAJOR
                (0, 2, 0),           # SYN_MT_REPORT
            ])
        events.append((0, 0, 0))  # SYN_REPORT
        self._adb.send_sendevent_batch(device, events)

        # Brief hold
        time.sleep(0.05)

        # All fingers up
        events = []
        for idx in range(len(pixel_points)):
            events.extend([
                (3, 57, -1),
                (0, 2, 0),
            ])
        events.append((0, 0, 0))
        return self._adb.send_sendevent_batch(device, events)

    def touch_down(self, x: float, y: float, pointer_id: int = 0) -> bool:
        """Start a touch at coordinates (for continuous control like joystick)."""
        px, py = self.normalize_coords(x, y)
        self._active_pointers[pointer_id] = (px, py)

        if self._use_sendevent:
            device = self._adb.touch_device
            events = [
                (3, 57, pointer_id + 100),
                (3, 53, px),
                (3, 54, py),
                (3, 48, 50),
                (0, 2, 0),
                (0, 0, 0),
            ]
            return self._adb.send_sendevent_batch(device, events)
        return self._adb.send_tap(px, py)

    def touch_move(self, x: float, y: float, pointer_id: int = 0) -> bool:
        """Move an active touch to new coordinates."""
        px, py = self.normalize_coords(x, y)
        self._active_pointers[pointer_id] = (px, py)

        if self._use_sendevent:
            device = self._adb.touch_device
            events = [
                (3, 57, pointer_id + 100),
                (3, 53, px),
                (3, 54, py),
                (3, 48, 50),
                (0, 2, 0),
                (0, 0, 0),
            ]
            return self._adb.send_sendevent_batch(device, events)
        return True

    def touch_up(self, pointer_id: int = 0) -> bool:
        """End an active touch."""
        self._active_pointers.pop(pointer_id, None)

        if self._use_sendevent:
            device = self._adb.touch_device
            events = [
                (3, 57, -1),
                (0, 2, 0),
                (0, 0, 0),
            ]
            return self._adb.send_sendevent_batch(device, events)
        return True

    def start_batching(self):
        """Start the event batching thread."""
        if self._batch_running:
            return
        self._batch_running = True
        self._batch_thread = threading.Thread(target=self._batch_loop, daemon=True)
        self._batch_thread.start()

    def stop_batching(self):
        """Stop the event batching thread."""
        self._batch_running = False
        if self._batch_thread:
            self._batch_thread.join(timeout=1.0)
            self._batch_thread = None

    def _batch_loop(self):
        """Background thread that processes queued events in batches."""
        while self._batch_running:
            if self._event_queue:
                batch = []
                while self._event_queue and len(batch) < 20:
                    batch.append(self._event_queue.popleft())
                if batch:
                    self._process_batch(batch)
            time.sleep(self._batch_interval)

    def _process_batch(self, batch: list):
        """Process a batch of queued events."""
        for event in batch:
            try:
                event_type = event.get("type")
                if event_type == "tap":
                    self.inject_tap(event["x"], event["y"], event.get("pointer_id", 0))
                elif event_type == "swipe":
                    self.inject_swipe(
                        event["x1"], event["y1"],
                        event["x2"], event["y2"],
                        event.get("duration_ms", 300),
                        event.get("pointer_id", 0)
                    )
            except Exception as e:
                logger.error(f"Batch event error: {e}")

    def queue_event(self, event: dict):
        """Queue an event for batch processing."""
        self._event_queue.append(event)

    def set_use_sendevent(self, enabled: bool):
        """Toggle between sendevent (fast) and input command (compatible)."""
        self._use_sendevent = enabled

    def refresh_resolution(self):
        """Force refresh of cached device resolution."""
        self._resolution = None
        self._ensure_resolution()
