"""
ADB connection manager for scrcpy-gamepad.
Handles device communication via ADB subprocess.
"""

import re
import subprocess
import threading
import time
import logging
from typing import Optional, List, Tuple

logger = logging.getLogger(__name__)


class ADBManager:
    """Thread-safe ADB connection manager with connection pooling."""

    def __init__(self, adb_path: str = "adb", device_serial: Optional[str] = None):
        self._adb_path = adb_path
        self._device_serial = device_serial
        self._connected = False
        self._lock = threading.Lock()
        self._shell_lock = threading.Lock()
        self._process: Optional[subprocess.Popen] = None
        self._touch_device: Optional[str] = None
        self._resolution: Optional[Tuple[int, int]] = None
        self._last_error: str = ""
        self._auto_reconnect = True
        self._reconnect_delay = 1.0
        self._max_retries = 3

    @property
    def device_serial(self) -> Optional[str]:
        return self._device_serial

    @device_serial.setter
    def device_serial(self, serial: Optional[str]):
        with self._lock:
            self._device_serial = serial

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def last_error(self) -> str:
        return self._last_error

    @property
    def resolution(self) -> Optional[Tuple[int, int]]:
        return self._resolution

    def _build_cmd(self, *args) -> list:
        """Build ADB command with optional device serial."""
        cmd = [self._adb_path]
        if self._device_serial:
            cmd.extend(["-s", self._device_serial])
        cmd.extend(args)
        return cmd

    def _run_cmd(self, *args, timeout: float = 10.0, capture: bool = True) -> Tuple[int, str, str]:
        """Run an ADB command and return (returncode, stdout, stderr)."""
        cmd = self._build_cmd(*args)
        try:
            proc = subprocess.run(
                cmd,
                capture_output=capture,
                text=True,
                timeout=timeout,
            )
            stdout = proc.stdout if capture else ""
            stderr = proc.stderr if capture else ""
            return proc.returncode, stdout.strip(), stderr.strip()
        except subprocess.TimeoutExpired:
            return -1, "", "Command timed out"
        except FileNotFoundError:
            return -1, "", f"ADB not found at: {self._adb_path}"
        except Exception as e:
            return -1, "", str(e)

    def connect(self, address: Optional[str] = None, timeout: float = 10.0) -> bool:
        """
        Connect to a device. If address is given, connect via TCP/IP.
        Otherwise connect to first available USB device.
        """
        with self._lock:
            if address:
                rc, out, err = self._run_cmd("connect", address, timeout=timeout)
                if rc != 0 or "cannot" in out.lower():
                    self._last_error = f"Failed to connect to {address}: {err or out}"
                    logger.error(self._last_error)
                    return False
                self._device_serial = address

            # Verify connection
            rc, out, err = self._run_cmd("devices", timeout=timeout)
            if rc != 0:
                self._last_error = f"Failed to list devices: {err}"
                return False

            devices = self._parse_devices(out)
            if not devices:
                self._last_error = "No devices found"
                return False

            # Select device
            if self._device_serial:
                if self._device_serial not in [d[0] for d in devices]:
                    self._last_error = f"Device {self._device_serial} not found"
                    return False
            else:
                self._device_serial = devices[0][0]

            self._connected = True
            self._resolution = None  # Reset cached resolution
            self._touch_device = None  # Reset touch device
            self._find_touch_device()
            logger.info(f"Connected to device: {self._device_serial}")
            return True

    def disconnect(self):
        """Disconnect from the current device."""
        with self._lock:
            if self._device_serial and ":" in self._device_serial:
                # TCP device - disconnect
                self._run_cmd("disconnect", self._device_serial, timeout=5.0)
            self._connected = False
            self._device_serial = None
            self._resolution = None
            self._touch_device = None
            logger.info("Disconnected")

    def _parse_devices(self, output: str) -> List[Tuple[str, str]]:
        """Parse `adb devices` output into list of (serial, status)."""
        devices = []
        for line in output.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("List of"):
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                devices.append((parts[0], parts[1]))
        return devices

    def list_devices(self) -> List[Tuple[str, str]]:
        """Return list of (serial, status) for all connected devices."""
        rc, out, err = self._run_cmd("devices", timeout=5.0)
        if rc != 0:
            logger.error(f"Failed to list devices: {err}")
            return []
        return self._parse_devices(out)

    def send_shell(self, cmd: str, timeout: float = 10.0) -> Tuple[bool, str]:
        """Send a shell command to the device. Returns (success, output)."""
        with self._shell_lock:
            if not self._connected:
                if self._auto_reconnect:
                    if not self._reconnect():
                        return False, "Not connected"
                else:
                    return False, "Not connected"

            rc, out, err = self._run_cmd("shell", cmd, timeout=timeout)
            if rc != 0:
                if "device" in err.lower() and "not found" in err.lower():
                    self._connected = False
                    if self._auto_reconnect:
                        if self._reconnect():
                            rc, out, err = self._run_cmd("shell", cmd, timeout=timeout)
                            return rc == 0, out
                return False, err
            return True, out

    def _reconnect(self) -> bool:
        """Attempt to reconnect to the device."""
        for attempt in range(self._max_retries):
            logger.info(f"Reconnect attempt {attempt + 1}/{self._max_retries}")
            time.sleep(self._reconnect_delay)
            if self.connect(self._device_serial):
                return True
        return False

    def get_device_resolution(self) -> Optional[Tuple[int, int]]:
        """Get device screen resolution as (width, height)."""
        if self._resolution:
            return self._resolution

        ok, output = self.send_shell("wm size")
        if ok:
            match = re.search(r"(\d+)x(\d+)", output)
            if match:
                self._resolution = (int(match.group(1)), int(match.group(2)))
                return self._resolution
        return None

    def _find_touch_device(self):
        """Find the touchscreen input device path."""
        if self._touch_device:
            return
        ok, output = self.send_shell("getevent -pl 2>/dev/null | grep -B 10 ABS_MT_POSITION | head -1")
        if ok and output:
            # Extract device path like /dev/input/event2
            match = re.search(r"(/dev/input/event\d+)", output)
            if match:
                self._touch_device = match.group(1)
                logger.info(f"Touch device found: {self._touch_device}")
                return

        # Fallback: try common devices
        for dev in ["/dev/input/event2", "/dev/input/event1", "/dev/input/event0"]:
            ok, _ = self.send_shell(f"getevent -pl {dev} 2>/dev/null")
            if ok:
                self._touch_device = dev
                logger.info(f"Touch device (fallback): {self._touch_device}")
                return

        logger.warning("Could not find touch device, using default /dev/input/event2")
        self._touch_device = "/dev/input/event2"

    @property
    def touch_device(self) -> str:
        if not self._touch_device:
            self._find_touch_device()
        return self._touch_device or "/dev/input/event2"

    def send_touch(self, action: str, x: int, y: int, pointer_id: int = 0):
        """
        Send a touch event via ADB.
        action: 'down', 'move', 'up'
        """
        # Use input command for simplicity and compatibility
        if action == "down" or action == "move":
            # For tap, use input tap which is most reliable
            pass
        # The actual tap/swipe methods are preferred over this generic one

    def send_tap(self, x: int, y: int) -> bool:
        """Send a tap at absolute coordinates."""
        ok, out = self.send_shell(f"input touchscreen tap {x} {y}", timeout=5.0)
        if not ok:
            logger.warning(f"Tap failed: {out}")
        return ok

    def send_swipe(self, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300) -> bool:
        """Send a swipe gesture."""
        ok, out = self.send_shell(
            f"input touchscreen swipe {x1} {y1} {x2} {y2} {duration_ms}",
            timeout=5.0
        )
        if not ok:
            logger.warning(f"Swipe failed: {out}")
        return ok

    def send_long_press(self, x: int, y: int, duration_ms: int = 500) -> bool:
        """Send a long press (swipe with same start/end)."""
        return self.send_swipe(x, y, x, y, duration_ms)

    def send_sendevent(self, device: str, event_type: int, code: int, value: int) -> bool:
        """Send a single sendevent command."""
        ok, out = self.send_shell(
            f"sendevent {device} {event_type} {code} {value}",
            timeout=2.0
        )
        return ok

    def send_sendevent_batch(self, device: str, events: List[Tuple[int, int, int]]) -> bool:
        """
        Send multiple sendevent commands in a single shell call for lower latency.
        events: list of (event_type, code, value)
        """
        if not events:
            return True

        # Build compound command
        cmds = "; ".join(
            f"sendevent {device} {et} {c} {v}"
            for et, c, v in events
        )
        ok, out = self.send_shell(cmds, timeout=5.0)
        if not ok:
            logger.warning(f"sendevent batch failed: {out}")
        return ok

    def send_multi_touch(self, points: List[Tuple[int, int]], action: str = "down") -> bool:
        """
        Send multi-touch events using sendevent.
        points: list of (x, y) coordinates
        action: 'down', 'move', 'up'
        """
        device = self.touch_device
        events = []

        if action == "down" or action == "move":
            for idx, (x, y) in enumerate(points):
                events.extend([
                    (3, 57, idx + 100),    # ABS_MT_TRACKING_ID
                    (3, 53, x),            # ABS_MT_POSITION_X
                    (3, 54, y),            # ABS_MT_POSITION_Y
                    (3, 48, 50),           # ABS_MT_TOUCH_MAJOR
                    (0, 2, 0),             # SYN_MT_REPORT
                ])
            events.append((0, 0, 0))  # SYN_REPORT
        elif action == "up":
            for idx in range(len(points)):
                events.extend([
                    (3, 57, -1),           # ABS_MT_TRACKING_ID (-1 = release)
                    (3, 53, 0),            # ABS_MT_POSITION_X
                    (3, 54, 0),            # ABS_MT_POSITION_Y
                    (3, 48, 0),            # ABS_MT_TOUCH_MAJOR
                    (0, 2, 0),             # SYN_MT_REPORT
                ])
            events.append((0, 0, 0))  # SYN_REPORT

        return self.send_sendevent_batch(device, events)

    def screenshot(self, local_path: str = "/tmp/scrcpy_gamepad_screenshot.png") -> Optional[str]:
        """Take a screenshot and pull it to local path."""
        remote_path = "/sdcard/screenshot.png"
        ok, _ = self.send_shell(f"screencap -p {remote_path}", timeout=10.0)
        if not ok:
            return None
        rc, _, _ = self._run_cmd("pull", remote_path, local_path, timeout=10.0)
        if rc != 0:
            return None
        self.send_shell(f"rm {remote_path}", timeout=2.0)
        return local_path
