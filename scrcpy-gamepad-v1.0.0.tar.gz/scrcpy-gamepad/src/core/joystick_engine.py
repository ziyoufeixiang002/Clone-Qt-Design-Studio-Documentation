"""
Virtual joystick engine for scrcpy-gamepad.
Maps keyboard WASD / gamepad stick to continuous touch swipe on Android.
"""

import math
import threading
import time
import logging
from typing import Optional, Tuple

from .touch_injector import TouchInjector

logger = logging.getLogger(__name__)


class JoystickEngine:
    """
    Virtual joystick that sends continuous touch-move events.
    Maps WASD keys or analog stick to a circular swipe gesture on screen.
    """

    def __init__(self, injector: TouchInjector):
        self._injector = injector
        self._lock = threading.Lock()

        # Joystick position on Android screen (normalized 0-1)
        self._center_x: float = 0.15
        self._center_y: float = 0.7
        self._radius: float = 0.08

        # Current state
        self._dx: float = 0.0  # -1 to 1
        self._dy: float = 0.0  # -1 to 1
        self._active: bool = False
        self._touch_started: bool = False

        # Configuration
        self._dead_zone: float = 0.15
        self._update_rate: int = 60  # Hz
        self._smoothing: float = 0.3  # Lower = smoother
        self._pointer_id: int = 5  # Unique pointer ID for joystick

        # Thread control
        self._thread: Optional[threading.Thread] = None
        self._running: bool = False

        # WASD key states
        self._key_states = {
            "W": False,
            "A": False,
            "S": False,
            "D": False,
        }

        # Previous smoothed values for interpolation
        self._prev_dx: float = 0.0
        self._prev_dy: float = 0.0

        # Callbacks
        self._on_direction_changed: Optional[callable] = None
        self._on_state_changed: Optional[callable] = None

    def set_center(self, x: float, y: float):
        """Set the center point of the virtual joystick on screen (normalized 0-1)."""
        with self._lock:
            self._center_x = max(0, min(1, x))
            self._center_y = max(0, min(1, y))

    def set_radius(self, r: float):
        """Set the max swipe distance (normalized 0-1)."""
        with self._lock:
            self._radius = max(0.01, min(0.5, r))

    def set_dead_zone(self, zone: float):
        """Set the dead zone (normalized 0-1)."""
        with self._lock:
            self._dead_zone = max(0, min(0.5, zone))

    def set_update_rate(self, rate: int):
        """Set the touch event update rate in Hz."""
        with self._lock:
            self._update_rate = max(10, min(120, rate))

    def set_smoothing(self, smoothing: float):
        """Set the interpolation smoothing factor (0=instant, 1=very smooth)."""
        with self._lock:
            self._smoothing = max(0, min(0.95, smoothing))

    def set_on_direction_changed(self, callback: callable):
        """Register callback for direction changes: callback(dx, dy)."""
        self._on_direction_changed = callback

    def set_on_state_changed(self, callback: callable):
        """Register callback for active state changes: callback(active)."""
        self._on_state_changed = callback

    def update_direction(self, dx: float, dy: float):
        """
        Update the joystick direction.
        dx, dy: normalized -1 to 1
        """
        with self._lock:
            # Apply dead zone
            magnitude = math.sqrt(dx * dx + dy * dy)
            if magnitude < self._dead_zone:
                self._dx = 0.0
                self._dy = 0.0
            else:
                # Normalize and scale
                if magnitude > 1.0:
                    dx /= magnitude
                    dy /= magnitude
                # Apply dead zone remapping
                effective_mag = (magnitude - self._dead_zone) / (1.0 - self._dead_zone)
                effective_mag = max(0, min(1, effective_mag))
                if magnitude > 0:
                    self._dx = (dx / magnitude) * effective_mag
                    self._dy = (dy / magnitude) * effective_mag
                else:
                    self._dx = 0.0
                    self._dy = 0.0

            was_active = self._active
            self._active = magnitude >= self._dead_zone

            if self._active and not was_active:
                self._start_touch()
            elif not self._active and was_active:
                self._stop_touch()

    def update_from_keys(self, w: bool, a: bool, s: bool, d: bool):
        """Update direction from WASD key states."""
        dx = 0.0
        dy = 0.0

        if a and not d:
            dx = -1.0
        elif d and not a:
            dx = 1.0

        if w and not s:
            dy = -1.0  # Up is negative Y
        elif s and not w:
            dy = 1.0

        # Normalize diagonal
        if dx != 0 and dy != 0:
            dx *= 0.7071  # 1/sqrt(2)
            dy *= 0.7071

        self._key_states["W"] = w
        self._key_states["A"] = a
        self._key_states["S"] = s
        self._key_states["D"] = d

        self.update_direction(dx, dy)

    def get_current_target(self) -> Tuple[float, float]:
        """Get the current touch target position (normalized coordinates)."""
        with self._lock:
            target_x = self._center_x + self._dx * self._radius
            target_y = self._center_y + self._dy * self._radius
            return (target_x, target_y)

    def _start_touch(self):
        """Start the touch at the joystick center."""
        if self._touch_started:
            return

        logger.debug(f"Joystick touch down at ({self._center_x:.3f}, {self._center_y:.3f})")
        self._injector.touch_down(self._center_x, self._center_y, self._pointer_id)
        self._touch_started = True

        if self._on_state_changed:
            self._on_state_changed(True)

    def _stop_touch(self):
        """Release the joystick touch."""
        if not self._touch_started:
            return

        logger.debug("Joystick touch up")
        self._injector.touch_up(self._pointer_id)
        self._touch_started = False
        self._prev_dx = 0.0
        self._prev_dy = 0.0

        if self._on_state_changed:
            self._on_state_changed(False)

    def start(self):
        """Start the joystick update thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()
        logger.info(f"Joystick engine started at {self._update_rate}Hz")

    def stop(self):
        """Stop the joystick update thread."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None
        self._stop_touch()
        logger.info("Joystick engine stopped")

    def _update_loop(self):
        """Main update loop - sends touch events at configured rate."""
        interval = 1.0 / self._update_rate

        while self._running:
            start_time = time.monotonic()

            with self._lock:
                if self._active and self._touch_started:
                    # Smooth interpolation
                    smooth_dx = self._prev_dx + (self._dx - self._prev_dx) * (1.0 - self._smoothing)
                    smooth_dy = self._prev_dy + (self._dy - self._prev_dy) * (1.0 - self._smoothing)
                    self._prev_dx = smooth_dx
                    self._prev_dy = smooth_dy

                    # Calculate target position
                    target_x = self._center_x + smooth_dx * self._radius
                    target_y = self._center_y + smooth_dy * self._radius

                    # Clamp to valid range
                    target_x = max(0, min(1, target_x))
                    target_y = max(0, min(1, target_y))

                    # Send touch move
                    self._injector.touch_move(target_x, target_y, self._pointer_id)

                    # Notify
                    if self._on_direction_changed:
                        self._on_direction_changed(smooth_dx, smooth_dy)

            # Maintain consistent update rate
            elapsed = time.monotonic() - start_time
            sleep_time = max(0, interval - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def direction(self) -> Tuple[float, float]:
        with self._lock:
            return (self._dx, self._dy)

    def configure(self, center_x: float, center_y: float, radius: float,
                  dead_zone: float = 0.15):
        """Configure all joystick parameters at once."""
        with self._lock:
            self._center_x = max(0, min(1, center_x))
            self._center_y = max(0, min(1, center_y))
            self._radius = max(0.01, min(0.5, radius))
            self._dead_zone = max(0, min(0.5, dead_zone))
