"""
Key mapping editor dialog for scrcpy-gamepad.
Full-featured editor for creating and modifying key mappings.
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QComboBox, QLineEdit, QPushButton, QLabel, QSpinBox, QDoubleSpinBox,
    QSlider, QListWidget, QListWidgetItem, QTabWidget, QWidget,
    QFileDialog, QMessageBox, QCheckBox, QSizePolicy, QApplication,
    QColorDialog, QGridLayout, QScrollArea
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QSize, QPointF
from PyQt6.QtGui import (
    QPainter, QPen, QBrush, QColor, QPixmap, QImage,
    QMouseEvent, QPaintEvent, QKeyEvent
)

from typing import Optional, Dict, Any, List, Tuple
from ..core.key_mapper import KeyMapper, KeyMapping, MappingAction
from ..config.default_profiles import get_all_profiles, get_profile_names


class ScreenPickerWidget(QWidget):
    """Widget that shows a screenshot and lets user click to pick coordinates."""

    coordinate_picked = pyqtSignal(float, float)  # x, y normalized

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pixmap: Optional[QPixmap] = None
        self._picked_point: Optional[QPointF] = None
        self._picking = False
        self.setMinimumSize(200, 350)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)

    def set_screenshot(self, pixmap: QPixmap):
        """Set the screenshot to display."""
        self._pixmap = pixmap
        self._picked_point = None
        self.update()

    def set_screenshot_from_path(self, path: str):
        """Load screenshot from file."""
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            self.set_screenshot(pixmap)

    def start_picking(self):
        """Enable coordinate picking mode."""
        self._picking = True
        self.setCursor(Qt.CursorShape.CrossCursor)

    def stop_picking(self):
        """Disable picking mode."""
        self._picking = False
        self.setCursor(Qt.CursorShape.ArrowCursor)

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Draw background
        painter.fillRect(self.rect(), QColor(30, 30, 35))

        if self._pixmap and not self._pixmap.isNull():
            # Scale pixmap to fit widget
            scaled = self._pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            # Center the pixmap
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

            # Draw picked point
            if self._picked_point:
                px = x + self._picked_point.x() * scaled.width()
                py = y + self._picked_point.y() * scaled.height()

                # Crosshair
                painter.setPen(QPen(QColor(0, 255, 136), 2))
                painter.drawLine(QPointF(px - 10, py), QPointF(px + 10, py))
                painter.drawLine(QPointF(px, py - 10), QPointF(px, py + 10))

                # Circle
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(QPointF(px, py), 8, 8)

                # Coordinate label
                painter.setPen(QPen(QColor(255, 255, 255)))
                painter.drawText(
                    int(px + 12), int(py - 5),
                    f"({self._picked_point.x():.2f}, {self._picked_point.y():.2f})"
                )
        else:
            painter.setPen(QPen(QColor(120, 120, 130)))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No screenshot\nClick 'Take Screenshot'")

        painter.end()

    def mousePressEvent(self, event: QMouseEvent):
        if not self._picking or not self._pixmap:
            return
        if event.button() != Qt.MouseButton.LeftButton:
            return

        # Calculate normalized coordinates
        scaled = self._pixmap.scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        x_off = (self.width() - scaled.width()) // 2
        y_off = (self.height() - scaled.height()) // 2

        pos = event.position()
        nx = (pos.x() - x_off) / scaled.width()
        ny = (pos.y() - y_off) / scaled.height()

        if 0 <= nx <= 1 and 0 <= ny <= 1:
            self._picked_point = QPointF(nx, ny)
            self.coordinate_picked.emit(nx, ny)
            self.update()


class KeyRecordButton(QPushButton):
    """Button that records the next key press."""

    key_recorded = pyqtSignal(str)

    def __init__(self, text="Record Key", parent=None):
        super().__init__(text, parent)
        self._recording = False
        self._original_text = text

    def start_recording(self):
        self._recording = True
        self.setText("Press any key...")
        self.setFocus()
        self.setStyleSheet("background-color: #FF4444; color: white;")

    def stop_recording(self):
        self._recording = False
        self.setText(self._original_text)
        self.setStyleSheet("")

    def keyPressEvent(self, event: QKeyEvent):
        if self._recording:
            key_name = self._get_key_name(event)
            self.key_recorded.emit(key_name)
            self.stop_recording()
            event.accept()
        else:
            super().keyPressEvent(event)

    def _get_key_name(self, event: QKeyEvent) -> str:
        """Convert key event to readable name."""
        key = event.key()
        text = event.text()

        # Special keys
        special = {
            Qt.Key.Key_Space: "Space",
            Qt.Key.Key_Tab: "Tab",
            Qt.Key.Key_Return: "Enter",
            Qt.Key.Key_Enter: "Enter",
            Qt.Key.Key_Escape: "Escape",
            Qt.Key.Key_Backspace: "Backspace",
            Qt.Key.Key_Delete: "Delete",
            Qt.Key.Key_Shift: "Shift",
            Qt.Key.Key_Control: "Ctrl",
            Qt.Key.Key_Alt: "Alt",
            Qt.Key.Key_Meta: "Meta",
            Qt.Key.Key_Up: "Up",
            Qt.Key.Key_Down: "Down",
            Qt.Key.Key_Left: "Left",
            Qt.Key.Key_Right: "Right",
            Qt.Key.Key_F1: "F1",
            Qt.Key.Key_F2: "F2",
            Qt.Key.Key_F3: "F3",
            Qt.Key.Key_F4: "F4",
            Qt.Key.Key_F5: "F5",
            Qt.Key.Key_F6: "F6",
            Qt.Key.Key_F7: "F7",
            Qt.Key.Key_F8: "F8",
            Qt.Key.Key_F9: "F9",
            Qt.Key.Key_F10: "F10",
            Qt.Key.Key_F11: "F11",
            Qt.Key.Key_F12: "F12",
        }

        if key in special:
            return special[key]
        if text and text.isprintable():
            return text.upper()
        return f"Key_{key}"


class KeyEditorDialog(QDialog):
    """Dialog for editing key mappings."""

    mapping_changed = pyqtSignal()

    def __init__(self, mapper: KeyMapper, parent=None):
        super().__init__(parent)
        self._mapper = mapper
        self._current_mapping: Optional[KeyMapping] = None
        self._editing_index: int = -1

        self.setWindowTitle("Key Mapping Editor")
        self.setMinimumSize(800, 600)
        self._setup_ui()
        self._populate_list()
        self._load_presets()

    def _setup_ui(self):
        layout = QHBoxLayout(self)

        # Left panel - mapping list
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)

        # Preset dropdown
        preset_layout = QHBoxLayout()
        preset_layout.addWidget(QLabel("Preset:"))
        self._preset_combo = QComboBox()
        self._preset_combo.addItem("Custom")
        self._preset_combo.currentTextChanged.connect(self._on_preset_selected)
        preset_layout.addWidget(self._preset_combo)
        left_layout.addLayout(preset_layout)

        # Mapping list
        self._mapping_list = QListWidget()
        self._mapping_list.currentRowChanged.connect(self._on_mapping_selected)
        left_layout.addWidget(self._mapping_list)

        # List buttons
        btn_layout = QHBoxLayout()
        self._add_btn = QPushButton("Add")
        self._add_btn.clicked.connect(self._add_mapping)
        self._del_btn = QPushButton("Delete")
        self._del_btn.clicked.connect(self._delete_mapping)
        self._clear_btn = QPushButton("Clear All")
        self._clear_btn.clicked.connect(self._clear_mappings)
        btn_layout.addWidget(self._add_btn)
        btn_layout.addWidget(self._del_btn)
        btn_layout.addWidget(self._clear_btn)
        left_layout.addLayout(btn_layout)

        # Import/Export
        io_layout = QHBoxLayout()
        import_btn = QPushButton("Import")
        import_btn.clicked.connect(self._import_profile)
        export_btn = QPushButton("Export")
        export_btn.clicked.connect(self._export_profile)
        io_layout.addWidget(import_btn)
        io_layout.addWidget(export_btn)
        left_layout.addLayout(io_layout)

        layout.addWidget(left_panel, 1)

        # Right panel - editor
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        # Tab widget for different mapping types
        self._tabs = QTabWidget()

        # Tab 1: TAP
        tap_tab = QWidget()
        tap_layout = QFormLayout(tap_tab)
        self._tap_key_record = KeyRecordButton("Record Key")
        self._tap_key_record.key_recorded.connect(lambda k: self._tap_key_input.setText(k))
        tap_layout.addRow("Key:", self._tap_key_record)
        self._tap_key_input = QLineEdit()
        tap_layout.addRow("Key Code:", self._tap_key_input)
        self._tap_x = QDoubleSpinBox()
        self._tap_x.setRange(0, 1)
        self._tap_x.setSingleStep(0.01)
        self._tap_x.setDecimals(3)
        tap_layout.addRow("X (0-1):", self._tap_x)
        self._tap_y = QDoubleSpinBox()
        self._tap_y.setRange(0, 1)
        self._tap_y.setSingleStep(0.01)
        self._tap_y.setDecimals(3)
        tap_layout.addRow("Y (0-1):", self._tap_y)
        self._tap_desc = QLineEdit()
        tap_layout.addRow("Description:", self._tap_desc)
        self._tabs.addTab(tap_tab, "Tap")

        # Tab 2: SWIPE
        swipe_tab = QWidget()
        swipe_layout = QFormLayout(swipe_tab)
        self._swipe_key_record = KeyRecordButton("Record Key")
        self._swipe_key_record.key_recorded.connect(lambda k: self._swipe_key_input.setText(k))
        swipe_layout.addRow("Key:", self._swipe_key_record)
        self._swipe_key_input = QLineEdit()
        swipe_layout.addRow("Key Code:", self._swipe_key_input)
        self._swipe_x1 = QDoubleSpinBox()
        self._swipe_x1.setRange(0, 1)
        self._swipe_x1.setSingleStep(0.01)
        self._swipe_x1.setDecimals(3)
        swipe_layout.addRow("Start X:", self._swipe_x1)
        self._swipe_y1 = QDoubleSpinBox()
        self._swipe_y1.setRange(0, 1)
        self._swipe_y1.setSingleStep(0.01)
        self._swipe_y1.setDecimals(3)
        swipe_layout.addRow("Start Y:", self._swipe_y1)
        self._swipe_x2 = QDoubleSpinBox()
        self._swipe_x2.setRange(0, 1)
        self._swipe_x2.setSingleStep(0.01)
        self._swipe_x2.setDecimals(3)
        swipe_layout.addRow("End X:", self._swipe_x2)
        self._swipe_y2 = QDoubleSpinBox()
        self._swipe_y2.setRange(0, 1)
        self._swipe_y2.setSingleStep(0.01)
        self._swipe_y2.setDecimals(3)
        swipe_layout.addRow("End Y:", self._swipe_y2)
        self._swipe_duration = QSpinBox()
        self._swipe_duration.setRange(50, 2000)
        self._swipe_duration.setValue(300)
        self._swipe_duration.setSuffix(" ms")
        swipe_layout.addRow("Duration:", self._swipe_duration)
        self._swipe_desc = QLineEdit()
        swipe_layout.addRow("Description:", self._swipe_desc)
        self._tabs.addTab(swipe_tab, "Swipe")

        # Tab 3: JOYSTICK
        joy_tab = QWidget()
        joy_layout = QFormLayout(joy_tab)
        self._joy_key_record = KeyRecordButton("Record Key")
        self._joy_key_record.key_recorded.connect(lambda k: self._joy_key_input.setText(k))
        joy_layout.addRow("Key:", self._joy_key_record)
        self._joy_key_input = QLineEdit()
        joy_layout.addRow("Key Code:", self._joy_key_input)
        self._joy_dir = QComboBox()
        self._joy_dir.addItems(["up", "down", "left", "right"])
        joy_layout.addRow("Direction:", self._joy_dir)
        self._joy_cx = QDoubleSpinBox()
        self._joy_cx.setRange(0, 1)
        self._joy_cx.setSingleStep(0.01)
        self._joy_cx.setDecimals(3)
        self._joy_cx.setValue(0.15)
        joy_layout.addRow("Center X:", self._joy_cx)
        self._joy_cy = QDoubleSpinBox()
        self._joy_cy.setRange(0, 1)
        self._joy_cy.setSingleStep(0.01)
        self._joy_cy.setDecimals(3)
        self._joy_cy.setValue(0.7)
        joy_layout.addRow("Center Y:", self._joy_cy)
        self._joy_radius = QDoubleSpinBox()
        self._joy_radius.setRange(0.01, 0.5)
        self._joy_radius.setSingleStep(0.005)
        self._joy_radius.setDecimals(3)
        self._joy_radius.setValue(0.08)
        joy_layout.addRow("Radius:", self._joy_radius)
        self._tabs.addTab(joy_tab, "Joystick")

        # Tab 4: LONG PRESS
        lp_tab = QWidget()
        lp_layout = QFormLayout(lp_tab)
        self._lp_key_record = KeyRecordButton("Record Key")
        self._lp_key_record.key_recorded.connect(lambda k: self._lp_key_input.setText(k))
        lp_layout.addRow("Key:", self._lp_key_record)
        self._lp_key_input = QLineEdit()
        lp_layout.addRow("Key Code:", self._lp_key_input)
        self._lp_x = QDoubleSpinBox()
        self._lp_x.setRange(0, 1)
        self._lp_x.setSingleStep(0.01)
        self._lp_x.setDecimals(3)
        lp_layout.addRow("X:", self._lp_x)
        self._lp_y = QDoubleSpinBox()
        self._lp_y.setRange(0, 1)
        self._lp_y.setSingleStep(0.01)
        self._lp_y.setDecimals(3)
        lp_layout.addRow("Y:", self._lp_y)
        self._lp_duration = QSpinBox()
        self._lp_duration.setRange(100, 5000)
        self._lp_duration.setValue(500)
        self._lp_duration.setSuffix(" ms")
        lp_layout.addRow("Duration:", self._lp_duration)
        self._lp_desc = QLineEdit()
        lp_layout.addRow("Description:", self._lp_desc)
        self._tabs.addTab(lp_tab, "Long Press")

        # Tab 5: MULTI TAP
        mt_tab = QWidget()
        mt_layout = QVBoxLayout(mt_tab)
        mt_form = QFormLayout()
        self._mt_key_record = KeyRecordButton("Record Key")
        self._mt_key_record.key_recorded.connect(lambda k: self._mt_key_input.setText(k))
        mt_form.addRow("Key:", self._mt_key_record)
        self._mt_key_input = QLineEdit()
        mt_form.addRow("Key Code:", self._mt_key_input)
        mt_layout.addLayout(mt_form)

        mt_layout.addWidget(QLabel("Tap Points (x, y):"))
        self._mt_points_list = QListWidget()
        mt_layout.addWidget(self._mt_points_list)

        mt_point_layout = QHBoxLayout()
        self._mt_px = QDoubleSpinBox()
        self._mt_px.setRange(0, 1)
        self._mt_px.setSingleStep(0.01)
        self._mt_px.setDecimals(3)
        self._mt_py = QDoubleSpinBox()
        self._mt_py.setRange(0, 1)
        self._mt_py.setSingleStep(0.01)
        self._mt_py.setDecimals(3)
        mt_add_btn = QPushButton("Add Point")
        mt_add_btn.clicked.connect(self._add_multi_tap_point)
        mt_del_btn = QPushButton("Remove")
        mt_del_btn.clicked.connect(self._remove_multi_tap_point)
        mt_point_layout.addWidget(QLabel("X:"))
        mt_point_layout.addWidget(self._mt_px)
        mt_point_layout.addWidget(QLabel("Y:"))
        mt_point_layout.addWidget(self._mt_py)
        mt_point_layout.addWidget(mt_add_btn)
        mt_point_layout.addWidget(mt_del_btn)
        mt_layout.addLayout(mt_point_layout)

        self._mt_desc = QLineEdit()
        mt_desc_layout = QFormLayout()
        mt_desc_layout.addRow("Description:", self._mt_desc)
        mt_layout.addLayout(mt_desc_layout)

        self._tabs.addTab(mt_tab, "Multi Tap")

        # Tab 6: Screen Picker
        picker_tab = QWidget()
        picker_layout = QVBoxLayout(picker_tab)
        self._screen_picker = ScreenPickerWidget()
        self._screen_picker.coordinate_picked.connect(self._on_coordinate_picked)
        picker_layout.addWidget(self._screen_picker)
        picker_btn_layout = QHBoxLayout()
        screenshot_btn = QPushButton("Take Screenshot")
        screenshot_btn.clicked.connect(self._take_screenshot)
        pick_btn = QPushButton("Pick Coordinates")
        pick_btn.clicked.connect(self._screen_picker.start_picking)
        picker_btn_layout.addWidget(screenshot_btn)
        picker_btn_layout.addWidget(pick_btn)
        picker_layout.addLayout(picker_btn_layout)
        self._tabs.addTab(picker_tab, "Screen Picker")

        right_layout.addWidget(self._tabs)

        # Action buttons
        action_layout = QHBoxLayout()
        save_btn = QPushButton("Save Mapping")
        save_btn.clicked.connect(self._save_current_mapping)
        save_btn.setStyleSheet("background-color: #2196F3; color: white; padding: 8px;")
        test_btn = QPushButton("Test")
        test_btn.clicked.connect(self._test_mapping)
        test_btn.setStyleSheet("background-color: #4CAF50; color: white; padding: 8px;")
        action_layout.addWidget(save_btn)
        action_layout.addWidget(test_btn)
        right_layout.addLayout(action_layout)

        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        right_layout.addWidget(close_btn)

        layout.addWidget(right_panel, 2)

    def _load_presets(self):
        """Load preset profiles into dropdown."""
        for name in get_profile_names():
            self._preset_combo.addItem(name)

    def _on_preset_selected(self, name: str):
        """Handle preset selection."""
        from ..config.default_profiles import get_profile
        profile = get_profile(name)
        if profile:
            reply = QMessageBox.question(
                self, "Load Preset",
                f"Load '{name}' profile? This will replace current mappings.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self._mapper.load_from_dict(profile)
                self._populate_list()

    def _populate_list(self):
        """Populate the mapping list from mapper."""
        self._mapping_list.clear()
        for mapping in self._mapper.get_mapping_list():
            mod = f"[{mapping.modifier}] " if mapping.modifier else ""
            desc = mapping.description or mapping.action.value
            item_text = f"{mod}{mapping.key} → {desc} ({mapping.action.value})"
            self._mapping_list.addItem(item_text)

    def _on_mapping_selected(self, index: int):
        """Handle mapping selection in list."""
        mappings = self._mapper.get_mapping_list()
        if 0 <= index < len(mappings):
            self._current_mapping = mappings[index]
            self._editing_index = index
            self._populate_editor(self._current_mapping)

    def _populate_editor(self, mapping: KeyMapping):
        """Fill editor fields from a mapping."""
        action = mapping.action
        params = mapping.params

        if action == MappingAction.TAP:
            self._tabs.setCurrentIndex(0)
            self._tap_key_input.setText(mapping.key)
            self._tap_x.setValue(params.get("x", 0))
            self._tap_y.setValue(params.get("y", 0))
            self._tap_desc.setText(mapping.description)

        elif action == MappingAction.SWIPE:
            self._tabs.setCurrentIndex(1)
            self._swipe_key_input.setText(mapping.key)
            self._swipe_x1.setValue(params.get("x1", 0))
            self._swipe_y1.setValue(params.get("y1", 0))
            self._swipe_x2.setValue(params.get("x2", 0))
            self._swipe_y2.setValue(params.get("y2", 0))
            self._swipe_duration.setValue(params.get("duration_ms", 300))
            self._swipe_desc.setText(mapping.description)

        elif action == MappingAction.JOYSTICK:
            self._tabs.setCurrentIndex(2)
            self._joy_key_input.setText(mapping.key)
            self._joy_dir.setCurrentText(params.get("direction", "up"))
            self._joy_cx.setValue(params.get("center_x", 0.15))
            self._joy_cy.setValue(params.get("center_y", 0.7))
            self._joy_radius.setValue(params.get("radius", 0.08))

        elif action == MappingAction.LONG_PRESS:
            self._tabs.setCurrentIndex(3)
            self._lp_key_input.setText(mapping.key)
            self._lp_x.setValue(params.get("x", 0))
            self._lp_y.setValue(params.get("y", 0))
            self._lp_duration.setValue(params.get("duration_ms", 500))
            self._lp_desc.setText(mapping.description)

        elif action == MappingAction.MULTI_TAP:
            self._tabs.setCurrentIndex(4)
            self._mt_key_input.setText(mapping.key)
            self._mt_points_list.clear()
            for x, y in params.get("points", []):
                self._mt_points_list.addItem(f"({x:.3f}, {y:.3f})")
            self._mt_desc.setText(mapping.description)

    def _save_current_mapping(self):
        """Save the current editor state as a mapping."""
        tab = self._tabs.currentIndex()

        if tab == 0:  # Tap
            key = self._tap_key_input.text().strip()
            if not key:
                QMessageBox.warning(self, "Error", "Key code is required")
                return
            self._mapper.add_mapping(
                key, MappingAction.TAP,
                {"x": self._tap_x.value(), "y": self._tap_y.value(), "coordinate_mode": "normalized"},
                description=self._tap_desc.text()
            )

        elif tab == 1:  # Swipe
            key = self._swipe_key_input.text().strip()
            if not key:
                QMessageBox.warning(self, "Error", "Key code is required")
                return
            self._mapper.add_mapping(
                key, MappingAction.SWIPE,
                {
                    "x1": self._swipe_x1.value(), "y1": self._swipe_y1.value(),
                    "x2": self._swipe_x2.value(), "y2": self._swipe_y2.value(),
                    "duration_ms": self._swipe_duration.value(),
                    "coordinate_mode": "normalized"
                },
                description=self._swipe_desc.text()
            )

        elif tab == 2:  # Joystick
            key = self._joy_key_input.text().strip()
            if not key:
                QMessageBox.warning(self, "Error", "Key code is required")
                return
            self._mapper.add_mapping(
                key, MappingAction.JOYSTICK,
                {
                    "direction": self._joy_dir.currentText(),
                    "center_x": self._joy_cx.value(),
                    "center_y": self._joy_cy.value(),
                    "radius": self._joy_radius.value(),
                },
                group="movement"
            )

        elif tab == 3:  # Long Press
            key = self._lp_key_input.text().strip()
            if not key:
                QMessageBox.warning(self, "Error", "Key code is required")
                return
            self._mapper.add_mapping(
                key, MappingAction.LONG_PRESS,
                {
                    "x": self._lp_x.value(), "y": self._lp_y.value(),
                    "duration_ms": self._lp_duration.value(),
                    "coordinate_mode": "normalized"
                },
                description=self._lp_desc.text()
            )

        elif tab == 4:  # Multi Tap
            key = self._mt_key_input.text().strip()
            if not key:
                QMessageBox.warning(self, "Error", "Key code is required")
                return
            points = []
            for i in range(self._mt_points_list.count()):
                text = self._mt_points_list.item(i).text()
                text = text.strip("()")
                parts = text.split(",")
                if len(parts) == 2:
                    points.append((float(parts[0].strip()), float(parts[1].strip())))
            self._mapper.add_mapping(
                key, MappingAction.MULTI_TAP,
                {"points": points, "coordinate_mode": "normalized"},
                description=self._mt_desc.text()
            )

        self._populate_list()
        self.mapping_changed.emit()
        QMessageBox.information(self, "Saved", "Mapping saved successfully")

    def _add_mapping(self):
        """Add a new blank mapping."""
        self._tap_key_input.clear()
        self._tap_x.setValue(0.5)
        self._tap_y.setValue(0.5)
        self._tap_desc.clear()
        self._tabs.setCurrentIndex(0)
        self._current_mapping = None
        self._editing_index = -1

    def _delete_mapping(self):
        """Delete the selected mapping."""
        index = self._mapping_list.currentRow()
        mappings = self._mapper.get_mapping_list()
        if 0 <= index < len(mappings):
            mapping = mappings[index]
            self._mapper.remove_mapping(mapping.key, mapping.modifier)
            self._populate_list()
            self.mapping_changed.emit()

    def _clear_mappings(self):
        """Clear all mappings."""
        reply = QMessageBox.question(
            self, "Clear All",
            "Remove all key mappings?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._mapper.clear_all()
            self._populate_list()
            self.mapping_changed.emit()

    def _add_multi_tap_point(self):
        """Add a point to multi-tap list."""
        x = self._mt_px.value()
        y = self._mt_py.value()
        self._mt_points_list.addItem(f"({x:.3f}, {y:.3f})")

    def _remove_multi_tap_point(self):
        """Remove selected point from multi-tap list."""
        row = self._mt_points_list.currentRow()
        if row >= 0:
            self._mt_points_list.takeItem(row)

    def _on_coordinate_picked(self, x: float, y: float):
        """Handle coordinate picked from screen."""
        # Fill current tab's coordinates
        tab = self._tabs.currentIndex()
        if tab == 0:
            self._tap_x.setValue(x)
            self._tap_y.setValue(y)
        elif tab == 3:
            self._lp_x.setValue(x)
            self._lp_y.setValue(y)

    def _take_screenshot(self):
        """Take a screenshot from the device."""
        # This would call ADBManager.screenshot() - placeholder for now
        # In real use, the main window passes the screenshot path
        QMessageBox.information(self, "Screenshot",
                                "Screenshot feature requires device connection.\n"
                                "Connect to a device first, then try again.")

    def _test_mapping(self):
        """Test the current mapping."""
        QMessageBox.information(self, "Test",
                                "Test mode: press the mapped key to verify the action.")

    def _import_profile(self):
        """Import a profile from JSON file."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Profile", "", "JSON Files (*.json)"
        )
        if path:
            self._mapper.load_profile(path)
            self._populate_list()
            self.mapping_changed.emit()

    def _export_profile(self):
        """Export current mappings to JSON file."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Profile", "", "JSON Files (*.json)"
        )
        if path:
            self._mapper.save_profile(path)
            QMessageBox.information(self, "Exported", f"Profile saved to {path}")
