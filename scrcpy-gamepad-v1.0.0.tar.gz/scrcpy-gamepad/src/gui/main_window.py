"""
Main application window for scrcpy-gamepad.
Central hub for device control, screen mirroring, and key mapping.
"""

import os
import sys
import subprocess
import logging
import json
from pathlib import Path
from typing import Optional, List, Tuple

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QGroupBox, QLineEdit, QPushButton, QComboBox, QLabel,
    QToolBar, QStatusBar, QMenuBar, QMenu, QFileDialog,
    QMessageBox, QApplication, QSizePolicy, QTextEdit,
    QDockWidget, QListWidget, QListWidgetItem, QCheckBox,
    QFrame
)
from PyQt6.QtCore import (
    Qt, QSettings, QTimer, pyqtSignal, QThread, QSize, QProcess
)
from PyQt6.QtGui import QAction, QIcon, QPixmap, QFont, QKeyEvent, QCloseEvent

from ..core.adb_manager import ADBManager
from ..core.touch_injector import TouchInjector
from ..core.key_mapper import KeyMapper, KeyMapping, MappingAction
from ..core.joystick_engine import JoystickEngine
from ..config.settings import Settings
from ..config.default_profiles import get_profile_names, get_profile
from .key_editor_dialog import KeyEditorDialog
from .screen_overlay import ScreenOverlay
from .joystick_widget import JoystickWidget

logger = logging.getLogger(__name__)

# Dark theme stylesheet
DARK_THEME = """
QMainWindow, QDialog {
    background-color: #1e1e22;
    color: #d4d4d8;
}
QWidget {
    background-color: #1e1e22;
    color: #d4d4d8;
    font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
    font-size: 13px;
}
QGroupBox {
    border: 1px solid #3a3a40;
    border-radius: 6px;
    margin-top: 12px;
    padding-top: 14px;
    font-weight: bold;
    color: #a0a0b0;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
}
QPushButton {
    background-color: #2d2d33;
    border: 1px solid #3a3a40;
    border-radius: 4px;
    padding: 6px 16px;
    color: #d4d4d8;
    min-height: 24px;
}
QPushButton:hover {
    background-color: #3a3a44;
    border-color: #505060;
}
QPushButton:pressed {
    background-color: #25252b;
}
QPushButton#connectBtn {
    background-color: #1a73e8;
    border-color: #1a73e8;
    color: white;
    font-weight: bold;
}
QPushButton#connectBtn:hover {
    background-color: #2b7de9;
}
QPushButton#disconnectBtn {
    background-color: #d32f2f;
    border-color: #d32f2f;
    color: white;
}
QPushButton#disconnectBtn:hover {
    background-color: #e33e3e;
}
QPushButton#startMirrorBtn {
    background-color: #388e3c;
    border-color: #388e3c;
    color: white;
    font-weight: bold;
}
QPushButton#startMirrorBtn:hover {
    background-color: #43a047;
}
QLineEdit, QComboBox {
    background-color: #25252b;
    border: 1px solid #3a3a40;
    border-radius: 4px;
    padding: 5px 8px;
    color: #d4d4d8;
}
QLineEdit:focus, QComboBox:focus {
    border-color: #1a73e8;
}
QComboBox::drop-down {
    border: none;
    padding-right: 8px;
}
QComboBox QAbstractItemView {
    background-color: #25252b;
    border: 1px solid #3a3a40;
    color: #d4d4d8;
    selection-background-color: #1a73e8;
}
QListWidget {
    background-color: #25252b;
    border: 1px solid #3a3a40;
    border-radius: 4px;
    alternate-background-color: #2a2a30;
}
QListWidget::item {
    padding: 4px 8px;
    border-bottom: 1px solid #2a2a30;
}
QListWidget::item:selected {
    background-color: #1a73e8;
    color: white;
}
QListWidget::item:hover {
    background-color: #333340;
}
QToolBar {
    background-color: #25252b;
    border-bottom: 1px solid #3a3a40;
    spacing: 4px;
    padding: 2px;
}
QToolBar QToolButton {
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 4px;
    padding: 4px 8px;
    color: #d4d4d8;
}
QToolBar QToolButton:hover {
    background-color: #333340;
    border-color: #3a3a40;
}
QStatusBar {
    background-color: #18181c;
    border-top: 1px solid #3a3a40;
    color: #808090;
    font-size: 12px;
}
QMenuBar {
    background-color: #25252b;
    border-bottom: 1px solid #3a3a40;
    color: #d4d4d8;
}
QMenuBar::item:selected {
    background-color: #333340;
}
QMenu {
    background-color: #25252b;
    border: 1px solid #3a3a40;
    color: #d4d4d8;
}
QMenu::item:selected {
    background-color: #1a73e8;
}
QSplitter::handle {
    background-color: #3a3a40;
}
QTextEdit {
    background-color: #1a1a1e;
    border: 1px solid #3a3a40;
    border-radius: 4px;
    color: #a0a0b0;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 11px;
}
QDockWidget {
    color: #d4d4d8;
    titlebar-close-icon: none;
}
QDockWidget::title {
    background-color: #25252b;
    padding: 6px;
    border-bottom: 1px solid #3a3a40;
}
QFrame#separator {
    background-color: #3a3a40;
    max-height: 1px;
}
QLabel#statusConnected {
    color: #4CAF50;
    font-weight: bold;
}
QLabel#statusDisconnected {
    color: #f44336;
    font-weight: bold;
}
"""


class ScrcpyLauncher:
    """Manages scrcpy subprocess lifecycle."""

    def __init__(self, scrcpy_path: str = "scrcpy"):
        self._scrcpy_path = scrcpy_path
        self._process: Optional[QProcess] = None
        self._running = False

    @property
    def is_running(self) -> bool:
        return self._running and self._process is not None

    def start(self, device_serial: Optional[str] = None, extra_args: Optional[List[str]] = None):
        """Launch scrcpy."""
        if self.is_running:
            return

        args = []
        if device_serial:
            args.extend(["--serial", device_serial])
        args.extend([
            "--window-title", "Scrcpy GamePad - Screen Mirror",
            "--render-driver", "opengl",
            "--video-codec", "h264",
            "--max-size", "1024",
            "--video-bit-rate", "8M",
            "--max-fps", "60",
        ])
        if extra_args:
            args.extend(extra_args)

        self._process = QProcess()
        self._process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self._process.finished.connect(self._on_finished)
        self._process.errorOccurred.connect(self._on_error)

        logger.info(f"Starting scrcpy: {self._scrcpy_path} {' '.join(args)}")
        self._process.start(self._scrcpy_path, args)

        if self._process.waitForStarted(5000):
            self._running = True
            logger.info("scrcpy started successfully")
        else:
            logger.error("Failed to start scrcpy")
            self._process = None

    def stop(self):
        """Stop scrcpy."""
        if self._process and self._running:
            self._process.terminate()
            if not self._process.waitForFinished(3000):
                self._process.kill()
            self._running = False
            self._process = None
            logger.info("scrcpy stopped")

    def _on_finished(self, exit_code, exit_status):
        self._running = False
        self._process = None
        logger.info(f"scrcpy exited with code {exit_code}")

    def _on_error(self, error):
        self._running = False
        logger.error(f"scrcpy error: {error}")


class MainWindow(QMainWindow):
    """Main application window."""

    # Custom signals
    device_connected = pyqtSignal(str)
    device_disconnected = pyqtSignal()
    key_event_received = pyqtSignal(str, bool)

    def __init__(self):
        super().__init__()
        self._settings = Settings()
        self._adb = ADBManager(adb_path=self._settings.adb_path)
        self._injector = TouchInjector(self._adb, use_sendevent=self._settings.use_sendevent)
        self._mapper = KeyMapper()
        self._joystick = JoystickEngine(self._injector)
        self._scrcpy = ScrcpyLauncher(self._settings.scrcpy_path)
        self._overlay = ScreenOverlay()

        self._setup_ui()
        self._setup_menu()
        self._setup_toolbar()
        self._setup_connections()
        self._restore_geometry()
        self._setup_key_handlers()

        # Status update timer
        self._status_timer = QTimer(self)
        self._status_timer.timeout.connect(self._update_status)
        self._status_timer.start(1000)

    def _setup_ui(self):
        """Build the UI layout."""
        self.setWindowTitle("Scrcpy GamePad - Android Game Controller")
        self.setMinimumSize(900, 600)

        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        # Left panel - Device connection
        left_panel = QGroupBox("Device Connection")
        left_panel.setFixedWidth(280)
        left_layout = QVBoxLayout(left_panel)

        # IP/Address input
        addr_layout = QHBoxLayout()
        addr_layout.addWidget(QLabel("Address:"))
        self._addr_input = QLineEdit()
        self._addr_input.setPlaceholderText("192.168.1.100:5555")
        self._addr_input.setText(self._settings.last_device_ip)
        addr_layout.addWidget(self._addr_input)
        left_layout.addLayout(addr_layout)

        # Device list
        left_layout.addWidget(QLabel("Available Devices:"))
        self._device_combo = QComboBox()
        self._device_combo.setMinimumWidth(200)
        left_layout.addWidget(self._device_combo)

        # Refresh button
        refresh_btn = QPushButton("Refresh Devices")
        refresh_btn.clicked.connect(self._refresh_devices)
        left_layout.addWidget(refresh_btn)

        # Connect/Disconnect
        btn_layout = QHBoxLayout()
        self._connect_btn = QPushButton("Connect")
        self._connect_btn.setObjectName("connectBtn")
        self._connect_btn.clicked.connect(self._connect_device)
        self._disconnect_btn = QPushButton("Disconnect")
        self._disconnect_btn.setObjectName("disconnectBtn")
        self._disconnect_btn.clicked.connect(self._disconnect_device)
        self._disconnect_btn.setEnabled(False)
        btn_layout.addWidget(self._connect_btn)
        btn_layout.addWidget(self._disconnect_btn)
        left_layout.addLayout(btn_layout)

        # Status indicator
        self._status_label = QLabel("● Disconnected")
        self._status_label.setObjectName("statusDisconnected")
        left_layout.addWidget(self._status_label)

        # Separator
        sep = QFrame()
        sep.setObjectName("separator")
        sep.setFrameShape(QFrame.Shape.HLine)
        left_layout.addWidget(sep)

        # Profile selection
        left_layout.addWidget(QLabel("Game Profile:"))
        self._profile_combo = QComboBox()
        self._profile_combo.addItem("None")
        for name in get_profile_names():
            self._profile_combo.addItem(name)
        self._profile_combo.currentTextChanged.connect(self._on_profile_changed)
        left_layout.addWidget(self._profile_combo)

        # Mirror controls
        sep2 = QFrame()
        sep2.setObjectName("separator")
        sep2.setFrameShape(QFrame.Shape.HLine)
        left_layout.addWidget(sep2)

        self._start_mirror_btn = QPushButton("Start Screen Mirror")
        self._start_mirror_btn.setObjectName("startMirrorBtn")
        self._start_mirror_btn.clicked.connect(self._toggle_mirror)
        left_layout.addWidget(self._start_mirror_btn)

        # Overlay toggle
        self._overlay_check = QCheckBox("Show Key Overlay")
        self._overlay_check.setChecked(True)
        self._overlay_check.toggled.connect(self._toggle_overlay)
        left_layout.addWidget(self._overlay_check)

        # Virtual joystick
        left_layout.addWidget(QLabel("Virtual Joystick:"))
        self._joystick_widget = JoystickWidget(size=140)
        self._joystick_widget.direction_changed.connect(self._on_joystick_direction)
        self._joystick_widget.stick_released.connect(self._on_joystick_released)
        left_layout.addWidget(self._joystick_widget, alignment=Qt.AlignmentFlag.AlignCenter)

        left_layout.addStretch()

        main_layout.addWidget(left_panel)

        # Center - Screen display area
        center_panel = QGroupBox("Screen Mirror")
        center_layout = QVBoxLayout(center_panel)
        self._screen_label = QLabel("Screen mirror will appear here\n\nConnect to device and start mirroring")
        self._screen_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._screen_label.setStyleSheet("""
            QLabel {
                background-color: #111115;
                border: 2px dashed #3a3a40;
                border-radius: 8px;
                color: #606070;
                font-size: 16px;
                padding: 40px;
            }
        """)
        center_layout.addWidget(self._screen_label)
        main_layout.addWidget(center_panel, 1)

        # Right panel - Key mappings
        right_panel = QGroupBox("Key Mappings")
        right_panel.setFixedWidth(280)
        right_layout = QVBoxLayout(right_panel)

        self._mapping_list = QListWidget()
        right_layout.addWidget(self._mapping_list)

        # Mapping buttons
        map_btn_layout = QHBoxLayout()
        edit_btn = QPushButton("Edit Mappings")
        edit_btn.clicked.connect(self._open_editor)
        map_btn_layout.addWidget(edit_btn)
        right_layout.addLayout(map_btn_layout)

        # Quick info
        right_layout.addWidget(QLabel("Quick Reference:"))
        info = QTextEdit()
        info.setReadOnly(True)
        info.setMaximumHeight(150)
        info.setPlainText(
            "F11 - Toggle fullscreen\n"
            "F12 - Toggle overlay\n"
            "ESC - Release mouse\n"
            "WASD - Movement\n"
            "Mouse - Aim/Touch"
        )
        right_layout.addWidget(info)

        right_layout.addStretch()
        main_layout.addWidget(right_panel)

        # Status bar
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._connection_status = QLabel("Not Connected")
        self._latency_label = QLabel("Latency: --")
        self._fps_label = QLabel("FPS: --")
        self._status_bar.addWidget(self._connection_status)
        self._status_bar.addPermanentWidget(self._latency_label)
        self._status_bar.addPermanentWidget(self._fps_label)

    def _setup_menu(self):
        """Create the menu bar."""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")

        load_action = QAction("Load Profile", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self._load_profile)
        file_menu.addAction(load_action)

        save_action = QAction("Save Profile", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self._save_profile)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Device menu
        device_menu = menubar.addMenu("Device")

        connect_action = QAction("Connect", self)
        connect_action.triggered.connect(self._connect_device)
        device_menu.addAction(connect_action)

        disconnect_action = QAction("Disconnect", self)
        disconnect_action.triggered.connect(self._disconnect_device)
        device_menu.addAction(disconnect_action)

        device_menu.addSeparator()

        screenshot_action = QAction("Take Screenshot", self)
        screenshot_action.setShortcut("Ctrl+P")
        screenshot_action.triggered.connect(self._take_screenshot)
        device_menu.addAction(screenshot_action)

        # Help menu
        help_menu = menubar.addMenu("Help")

        about_action = QAction("About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)

    def _setup_toolbar(self):
        """Create the toolbar."""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(20, 20))
        self.addToolBar(toolbar)

        # Start/Stop mirror
        self._mirror_action = QAction("▶ Mirror", self)
        self._mirror_action.triggered.connect(self._toggle_mirror)
        toolbar.addAction(self._mirror_action)

        toolbar.addSeparator()

        # Toggle overlay
        self._overlay_action = QAction("👁 Overlay", self)
        self._overlay_action.setCheckable(True)
        self._overlay_action.setChecked(True)
        self._overlay_action.triggered.connect(self._toggle_overlay)
        toolbar.addAction(self._overlay_action)

        toolbar.addSeparator()

        # Screenshot
        screenshot_action = QAction("📷 Screenshot", self)
        screenshot_action.triggered.connect(self._take_screenshot)
        toolbar.addAction(screenshot_action)

    def _setup_connections(self):
        """Connect signals and slots."""
        self.device_connected.connect(self._on_device_connected)
        self.device_disconnected.connect(self._on_device_disconnected)
        self.key_event_received.connect(self._on_key_event)

        # Mapper action handlers
        self._mapper.set_action_handler(MappingAction.TAP, self._handle_tap)
        self._mapper.set_action_handler(MappingAction.SWIPE, self._handle_swipe)
        self._mapper.set_action_handler(MappingAction.LONG_PRESS, self._handle_long_press)
        self._mapper.set_action_handler(MappingAction.MULTI_TAP, self._handle_multi_tap)
        self._mapper.set_action_handler(MappingAction.COMBO, self._handle_combo)
        self._mapper.set_action_handler(MappingAction.JOYSTICK, self._handle_joystick)

    def _setup_key_handlers(self):
        """Set up keyboard input handling."""
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def _restore_geometry(self):
        """Restore window geometry from settings."""
        settings = QSettings("ScrcpyGamePad", "MainWindow")
        geometry = settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        else:
            self.resize(self._settings.window_width, self._settings.window_height)

    def closeEvent(self, event: QCloseEvent):
        """Handle window close."""
        # Save geometry
        settings = QSettings("ScrcpyGamePad", "MainWindow")
        settings.setValue("geometry", self.saveGeometry())

        # Cleanup
        self._joystick.stop()
        self._scrcpy.stop()
        self._overlay.close()
        self._injector.stop_batching()

        if self._adb.is_connected:
            self._adb.disconnect()

        self._settings.save()
        event.accept()

    def keyPressEvent(self, event: QKeyEvent):
        """Handle key press events."""
        key_name = self._get_key_name(event)
        if key_name:
            self.key_event_received.emit(key_name, True)
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event: QKeyEvent):
        """Handle key release events."""
        key_name = self._get_key_name(event)
        if key_name:
            self.key_event_received.emit(key_name, False)
        super().keyReleaseEvent(event)

    def _get_key_name(self, event: QKeyEvent) -> Optional[str]:
        """Convert QKeyEvent to key name string."""
        key = event.key()
        text = event.text()

        special = {
            Qt.Key.Key_Space: "Space",
            Qt.Key.Key_Tab: "Tab",
            Qt.Key.Key_Return: "Enter",
            Qt.Key.Key_Escape: "Escape",
            Qt.Key.Key_Backspace: "Backspace",
            Qt.Key.Key_Shift: "Shift",
            Qt.Key.Key_Control: "Ctrl",
            Qt.Key.Key_Alt: "Alt",
            Qt.Key.Key_Up: "Up",
            Qt.Key.Key_Down: "Down",
            Qt.Key.Key_Left: "Left",
            Qt.Key.Key_Right: "Right",
            Qt.Key.Key_F11: "F11",
            Qt.Key.Key_F12: "F12",
        }

        # Handle F12 for overlay toggle
        if key == Qt.Key.Key_F12:
            self._overlay.toggle_visibility()
            return None

        if key in special:
            return special[key]
        if text and text.isprintable():
            return text.upper()
        return None

    def _on_key_event(self, key_name: str, is_pressed: bool):
        """Process a key event through the mapper."""
        if not self._adb.is_connected:
            return

        # Check for WASD joystick keys
        joystick_keys = {"W", "A", "S", "D"}
        if key_name in joystick_keys:
            # Update joystick widget state
            w = self._joystick_widget._key_states.get("W", False)
            a = self._joystick_widget._key_states.get("A", False)
            s = self._joystick_widget._key_states.get("S", False)
            d = self._joystick_widget._key_states.get("D", False)

            if key_name == "W":
                w = is_pressed
            elif key_name == "A":
                a = is_pressed
            elif key_name == "S":
                s = is_pressed
            elif key_name == "D":
                d = is_pressed

            self._joystick.update_from_keys(w, a, s, d)
            return

        # Process through mapper
        result = self._mapper.process_key_event(key_name, is_pressed)
        if result:
            logger.debug(f"Key mapped: {key_name} -> {result}")

    def _handle_tap(self, mapping: KeyMapping):
        """Handle a tap action."""
        params = mapping.params
        x = params.get("x", 0.5)
        y = params.get("y", 0.5)
        self._injector.inject_tap(x, y)

    def _handle_swipe(self, mapping: KeyMapping):
        """Handle a swipe action."""
        params = mapping.params
        self._injector.inject_swipe(
            params.get("x1", 0), params.get("y1", 0),
            params.get("x2", 0), params.get("y2", 0),
            params.get("duration_ms", 300)
        )

    def _handle_long_press(self, mapping: KeyMapping):
        """Handle a long press action."""
        params = mapping.params
        self._injector.inject_long_press(
            params.get("x", 0.5), params.get("y", 0.5),
            params.get("duration_ms", 500)
        )

    def _handle_multi_tap(self, mapping: KeyMapping):
        """Handle a multi-tap action."""
        points = mapping.params.get("points", [(0.5, 0.5)])
        self._injector.inject_multi_tap(points)

    def _handle_combo(self, mapping: KeyMapping):
        """Handle a combo action."""
        # Combos are handled by the mapper itself
        pass

    def _handle_joystick(self, mapping: KeyMapping):
        """Handle a joystick action."""
        # Joystick is handled via update_from_keys
        pass

    def _on_joystick_direction(self, dx: float, dy: float):
        """Handle joystick widget direction change."""
        self._joystick.update_direction(dx, dy)

    def _on_joystick_released(self):
        """Handle joystick widget release."""
        self._joystick.update_direction(0, 0)

    def _refresh_devices(self):
        """Refresh the device list."""
        self._device_combo.clear()
        devices = self._adb.list_devices()
        for serial, status in devices:
            self._device_combo.addItem(f"{serial} [{status}]", serial)
        if devices:
            self._status_bar.showMessage(f"Found {len(devices)} device(s)", 3000)

    def _connect_device(self):
        """Connect to the selected or entered device."""
        address = self._addr_input.text().strip()
        serial = self._device_combo.currentData()

        if not address and serial:
            address = serial
        elif not address and not serial:
            QMessageBox.warning(self, "Error", "Enter a device address or select from the list")
            return

        self._status_bar.showMessage(f"Connecting to {address}...")
        QApplication.processEvents()

        if self._adb.connect(address):
            self._settings.last_device_ip = address
            self._settings.last_device_serial = self._adb.device_serial
            self.device_connected.emit(self._adb.device_serial)
        else:
            QMessageBox.critical(self, "Connection Failed",
                                 f"Could not connect to {address}\n{self._adb.last_error}")

    def _disconnect_device(self):
        """Disconnect from the current device."""
        self._joystick.stop()
        self._scrcpy.stop()
        self._adb.disconnect()
        self.device_disconnected.emit()

    def _on_device_connected(self, serial: str):
        """Handle successful device connection."""
        self._connect_btn.setEnabled(False)
        self._disconnect_btn.setEnabled(True)
        self._status_label.setText(f"● Connected: {serial}")
        self._status_label.setObjectName("statusConnected")
        self._status_label.style().unpolish(self._status_label)
        self._status_label.style().polish(self._status_label)
        self._connection_status.setText(f"Connected: {serial}")

        # Get resolution
        resolution = self._adb.get_device_resolution()
        if resolution:
            self._overlay.set_screen_dimensions(resolution[0], resolution[1])
            self._status_bar.showMessage(f"Connected to {serial} ({resolution[0]}x{resolution[1]})", 5000)
        else:
            self._status_bar.showMessage(f"Connected to {serial}", 5000)

        # Start joystick engine
        self._joystick.configure(
            self._settings.joystick_center_x,
            self._settings.joystick_center_y,
            self._settings.joystick_radius,
            self._settings.dead_zone_size
        )
        self._joystick.start()
        self._injector.start_batching()

    def _on_device_disconnected(self):
        """Handle device disconnection."""
        self._connect_btn.setEnabled(True)
        self._disconnect_btn.setEnabled(False)
        self._status_label.setText("● Disconnected")
        self._status_label.setObjectName("statusDisconnected")
        self._status_label.style().unpolish(self._status_label)
        self._status_label.style().polish(self._status_label)
        self._connection_status.setText("Not Connected")
        self._start_mirror_btn.setText("Start Screen Mirror")
        self._mirror_action.setText("▶ Mirror")

    def _toggle_mirror(self):
        """Toggle screen mirroring."""
        if self._scrcpy.is_running:
            self._scrcpy.stop()
            self._start_mirror_btn.setText("Start Screen Mirror")
            self._mirror_action.setText("▶ Mirror")
            self._screen_label.setText("Screen mirror stopped")
        else:
            if not self._adb.is_connected:
                QMessageBox.warning(self, "Error", "Connect to a device first")
                return
            self._scrcpy.start(self._adb.device_serial)
            self._start_mirror_btn.setText("Stop Screen Mirror")
            self._mirror_action.setText("⏹ Stop")
            self._screen_label.setText("Screen mirror starting...\n\nscrcpy window will open separately")

    def _toggle_overlay(self, checked: bool):
        """Toggle the key mapping overlay."""
        self._overlay.toggle_visibility()

    def _on_profile_changed(self, name: str):
        """Handle profile selection change."""
        if name == "None":
            self._mapper.clear_all()
            return
        profile = get_profile(name)
        if profile:
            self._mapper.load_from_dict(profile)
            self._update_mapping_list()
            # Update joystick config
            joy_config = profile.get("joystick", {})
            if joy_config.get("enabled"):
                self._joystick.configure(
                    joy_config.get("center_x", 0.15),
                    joy_config.get("center_y", 0.7),
                    joy_config.get("radius", 0.08),
                    joy_config.get("dead_zone", 0.15)
                )
            self._status_bar.showMessage(f"Loaded profile: {name}", 3000)

    def _update_mapping_list(self):
        """Update the mapping list widget."""
        self._mapping_list.clear()
        for mapping in self._mapper.get_mapping_list():
            mod = f"[{mapping.modifier}] " if mapping.modifier else ""
            desc = mapping.description or mapping.action.value
            item_text = f"{mod}{mapping.key} → {desc}"
            self._mapping_list.addItem(item_text)

        # Update overlay
        self._overlay.update_indicators(self._mapper.mappings)

    def _open_editor(self):
        """Open the key mapping editor dialog."""
        dialog = KeyEditorDialog(self._mapper, self)
        dialog.mapping_changed.connect(self._update_mapping_list)
        dialog.exec()

    def _load_profile(self):
        """Load a profile from file."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Profile", "", "JSON Files (*.json)"
        )
        if path:
            self._mapper.load_profile(path)
            self._update_mapping_list()
            self._status_bar.showMessage(f"Loaded: {path}", 3000)

    def _save_profile(self):
        """Save current profile to file."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Profile", "", "JSON Files (*.json)"
        )
        if path:
            self._mapper.save_profile(path)
            self._status_bar.showMessage(f"Saved: {path}", 3000)

    def _take_screenshot(self):
        """Take a screenshot from the device."""
        if not self._adb.is_connected:
            QMessageBox.warning(self, "Error", "Connect to a device first")
            return
        result = self._adb.screenshot()
        if result:
            self._status_bar.showMessage(f"Screenshot saved: {result}", 3000)
        else:
            self._status_bar.showMessage("Screenshot failed", 3000)

    def _update_status(self):
        """Periodic status update."""
        if self._adb.is_connected:
            self._latency_label.setText(f"Latency: ~{5}ms")  # Placeholder
            self._fps_label.setText(f"Input Rate: {self._joystick._update_rate}Hz")
        else:
            self._latency_label.setText("Latency: --")
            self._fps_label.setText("FPS: --")

    def _show_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self, "About Scrcpy GamePad",
            "<h2>Scrcpy GamePad</h2>"
            "<p>Version 1.0.0</p>"
            "<p>Android game controller mapping tool built on scrcpy.</p>"
            "<p>Maps keyboard and mouse inputs to Android touch events "
            "for playing mobile games on PC.</p>"
            "<hr>"
            "<p>Built with PyQt6 and scrcpy.</p>"
            "<p>Licensed under Apache 2.0</p>"
        )
