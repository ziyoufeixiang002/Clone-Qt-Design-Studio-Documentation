"""
Screen overlay widget for scrcpy-gamepad.
Shows key mapping positions as labeled indicators on screen.
"""

from PyQt6.QtWidgets import QWidget, QApplication
from PyQt6.QtCore import Qt, pyqtSignal, QRectF, QPointF, QTimer
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QPainterPath

from typing import Dict, Any, List, Tuple


class ScreenOverlay(QWidget):
    """
    Semi-transparent overlay showing key mapping positions.
    Always-on-top, toggleable with F12.
    """

    toggle_requested = pyqtSignal()

    # Colors by action type
    ACTION_COLORS = {
        "tap": QColor(0, 255, 136, 180),       # Green
        "swipe": QColor(255, 102, 0, 180),      # Orange
        "joystick": QColor(0, 170, 255, 180),   # Blue
        "long_press": QColor(255, 0, 170, 180), # Pink
        "multi_tap": QColor(255, 255, 0, 180),  # Yellow
        "combo": QColor(170, 0, 255, 180),       # Purple
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self._indicators: List[Dict[str, Any]] = []
        self._visible = True
        self._editing = False
        self._screen_width = 1080
        self._screen_height = 2400
        self._overlay_scale = 1.0

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

        # Animation timer for pulsing effect
        self._pulse_phase = 0.0
        self._pulse_timer = QTimer(self)
        self._pulse_timer.timeout.connect(self._pulse_tick)
        self._pulse_timer.start(50)  # 20fps animation

    def set_screen_dimensions(self, width: int, height: int):
        """Set the Android screen dimensions for coordinate mapping."""
        self._screen_width = width
        self._screen_height = height

    def set_editing(self, editing: bool):
        """Enable/disable editing mode (allows click-through when not editing)."""
        self._editing = editing
        if editing:
            self.setWindowFlags(
                Qt.WindowType.FramelessWindowHint |
                Qt.WindowType.WindowStaysOnTopHint |
                Qt.WindowType.Tool
            )
        else:
            self.setWindowFlags(
                Qt.WindowType.FramelessWindowHint |
                Qt.WindowType.WindowStaysOnTopHint |
                Qt.WindowType.Tool |
                Qt.WindowType.WindowTransparentForInput
            )
        self.show()

    def update_indicators(self, mappings: Dict[str, Dict[str, Any]]):
        """Update the displayed indicators from key mappings."""
        self._indicators.clear()

        for key, mapping in mappings.items():
            action = mapping.get("action", "tap")
            params = mapping.get("params", {})
            desc = mapping.get("description", key)

            # Get coordinates
            x = params.get("x", params.get("center_x", 0))
            y = params.get("y", params.get("center_y", 0))

            # Handle coordinate modes
            coord_mode = params.get("coordinate_mode", "normalized")
            if coord_mode == "normalized":
                # Convert normalized to widget coordinates
                px = x * self.width()
                py = y * self.height()
            elif coord_mode == "percentage":
                px = (x / 100.0) * self.width()
                py = (y / 100.0) * self.height()
            else:
                # Absolute pixels - scale to widget
                px = (x / self._screen_width) * self.width()
                py = (y / self._screen_height) * self.height()

            self._indicators.append({
                "key": key,
                "action": action,
                "x": px,
                "y": py,
                "label": desc[:8] if desc else key,
                "color": self.ACTION_COLORS.get(action, QColor(200, 200, 200, 180)),
            })

        self.update()

    def _pulse_tick(self):
        """Update pulse animation."""
        self._pulse_phase = (self._pulse_phase + 0.1) % (3.14159 * 2)
        if self._visible and self._indicators:
            self.update()

    def paintEvent(self, event):
        """Draw the overlay indicators."""
        if not self._visible or not self._indicators:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Background tint
        painter.setBrush(QBrush(QColor(0, 0, 0, 30)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRect(self.rect())

        # Pulse factor for animation
        pulse = 1.0 + 0.15 * (1.0 + __import__('math').sin(self._pulse_phase))

        font = QFont("Consolas", 9, QFont.Weight.Bold)
        painter.setFont(font)

        for indicator in self._indicators:
            x = indicator["x"]
            y = indicator["y"]
            color = indicator["color"]
            label = indicator["label"]
            action = indicator["action"]

            # Scale indicator size with pulse
            base_r = 14
            r = base_r * pulse

            # Draw outer ring
            ring_color = QColor(color)
            ring_color.setAlpha(80)
            painter.setPen(QPen(ring_color, 2))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(QPointF(x, y), r + 4, r + 4)

            # Draw filled circle
            fill_color = QColor(color)
            fill_color.setAlpha(100)
            painter.setBrush(QBrush(fill_color))
            painter.setPen(QPen(color, 1.5))
            painter.drawEllipse(QPointF(x, y), r, r)

            # Draw action-specific icon
            painter.setPen(QPen(QColor(255, 255, 255, 200), 1.5))
            if action == "tap":
                # Small cross
                painter.drawLine(QPointF(x - 4, y), QPointF(x + 4, y))
                painter.drawLine(QPointF(x, y - 4), QPointF(x, y + 4))
            elif action == "swipe":
                # Arrow
                painter.drawLine(QPointF(x - 5, y), QPointF(x + 5, y))
                painter.drawLine(QPointF(x + 3, y - 3), QPointF(x + 5, y))
                painter.drawLine(QPointF(x + 3, y + 3), QPointF(x + 5, y))
            elif action == "joystick":
                # Circle with dot
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(QPointF(x, y), 5, 5)
                painter.setBrush(QBrush(QColor(255, 255, 255, 200)))
                painter.drawEllipse(QPointF(x, y), 2, 2)
            elif action == "long_press":
                # Clock-like icon
                painter.drawEllipse(QPointF(x, y), 5, 5)
                painter.drawLine(QPointF(x, y), QPointF(x, y - 4))
                painter.drawLine(QPointF(x, y), QPointF(x + 3, y))

            # Draw label below
            label_rect = QRectF(x - 20, y + r + 4, 40, 14)
            painter.setPen(QPen(QColor(255, 255, 255, 200)))
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, label)

        painter.end()

    def toggle_visibility(self):
        """Toggle overlay visibility."""
        self._visible = not self._visible
        if self._visible:
            self.show()
        else:
            self.hide()

    def set_overlay_opacity(self, opacity: float):
        """Set the overlay opacity (0.0 to 1.0)."""
        self.setWindowOpacity(max(0.0, min(1.0, opacity)))
