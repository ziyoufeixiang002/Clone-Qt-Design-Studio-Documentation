"""
Virtual joystick visualization widget for scrcpy-gamepad.
Renders a circular joystick with draggable thumb.
"""

import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, pyqtSignal, QPointF, QRectF, QTimer
from PyQt6.QtGui import (
    QPainter, QPen, QBrush, QColor, QRadialGradient,
    QMouseEvent, QPaintEvent, QResizeEvent, QKeyEvent
)


class JoystickWidget(QWidget):
    """
    Visual virtual joystick widget.
    Emits direction_changed(dx, dy) on stick movement.
    """

    direction_changed = pyqtSignal(float, float)  # dx, dy normalized -1 to 1
    stick_released = pyqtSignal()

    def __init__(self, parent=None, size: int = 160):
        super().__init__(parent)
        self._size = size
        self._center = QPointF(size / 2, size / 2)
        self._thumb_pos = QPointF(size / 2, size / 2)
        self._base_radius = size / 2 - 10
        self._thumb_radius = size / 6
        self._dead_zone_radius = self._base_radius * 0.15
        self._is_pressed = False
        self._dx = 0.0
        self._dy = 0.0

        # Colors
        self._bg_color = QColor(40, 40, 45, 180)
        self._ring_color = QColor(80, 80, 90, 200)
        self._thumb_color = QColor(0, 170, 255, 220)
        self._thumb_pressed_color = QColor(0, 200, 255, 255)
        self._dead_zone_color = QColor(60, 60, 70, 100)
        self._crosshair_color = QColor(100, 100, 110, 80)

        # WASD state
        self._key_states = {"W": False, "A": False, "S": False, "D": False}
        self._key_timer = QTimer(self)
        self._key_timer.timeout.connect(self._update_from_keys)
        self._key_timer.start(16)  # ~60Hz

        self.setFixedSize(size, size)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def _update_from_keys(self):
        """Update joystick position from WASD key states."""
        dx = 0.0
        dy = 0.0

        if self._key_states["A"] and not self._key_states["D"]:
            dx = -1.0
        elif self._key_states["D"] and not self._key_states["A"]:
            dx = 1.0

        if self._key_states["W"] and not self._key_states["S"]:
            dy = -1.0
        elif self._key_states["S"] and not self._key_states["W"]:
            dy = 1.0

        # Normalize diagonal
        if dx != 0 and dy != 0:
            dx *= 0.7071
            dy *= 0.7071

        if any(self._key_states.values()):
            self._set_thumb_from_direction(dx, dy)
            self._is_pressed = True
        elif not self._is_pressed or not any(self._key_states.values()):
            if self._is_pressed and not self._under_mouse_drag:
                self._reset_thumb()

    def _set_thumb_from_direction(self, dx: float, dy: float):
        """Set thumb position from normalized direction."""
        mag = math.sqrt(dx * dx + dy * dy)
        if mag > 1.0:
            dx /= mag
            dy /= mag

        # Apply dead zone
        if mag < 0.15:
            self._dx = 0.0
            self._dy = 0.0
        else:
            self._dx = dx
            self._dy = dy

        r = self._base_radius - self._thumb_radius
        self._thumb_pos = QPointF(
            self._center.x() + self._dx * r,
            self._center.y() + self._dy * r
        )
        self.direction_changed.emit(self._dx, self._dy)
        self.update()

    def _reset_thumb(self):
        """Reset thumb to center."""
        self._thumb_pos = QPointF(self._center)
        self._dx = 0.0
        self._dy = 0.0
        self._is_pressed = False
        self._under_mouse_drag = False
        self.stick_released.emit()
        self.update()

    def paintEvent(self, event: QPaintEvent):
        """Draw the joystick."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Background circle
        grad = QRadialGradient(self._center, self._base_radius)
        grad.setColorAt(0, self._bg_color.lighter(120))
        grad.setColorAt(1, self._bg_color)
        painter.setBrush(QBrush(grad))
        painter.setPen(QPen(self._ring_color, 2))
        painter.drawEllipse(self._center, self._base_radius, self._base_radius)

        # Dead zone circle
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(self._dead_zone_color))
        painter.drawEllipse(self._center, self._dead_zone_radius, self._dead_zone_radius)

        # Crosshair lines
        painter.setPen(QPen(self._crosshair_color, 1, Qt.PenStyle.DashLine))
        r = self._base_radius
        painter.drawLine(
            QPointF(self._center.x() - r, self._center.y()),
            QPointF(self._center.x() + r, self._center.y())
        )
        painter.drawLine(
            QPointF(self._center.x(), self._center.y() - r),
            QPointF(self._center.x(), self._center.y() + r)
        )

        # Direction line from center to thumb
        if self._is_pressed:
            painter.setPen(QPen(QColor(0, 170, 255, 60), 2))
            painter.drawLine(self._center, self._thumb_pos)

        # Thumb
        thumb_color = self._thumb_pressed_color if self._is_pressed else self._thumb_color
        thumb_grad = QRadialGradient(self._thumb_pos, self._thumb_radius)
        thumb_grad.setColorAt(0, thumb_color.lighter(130))
        thumb_grad.setColorAt(1, thumb_color)
        painter.setBrush(QBrush(thumb_grad))
        painter.setPen(QPen(thumb_color.lighter(150), 1.5))
        painter.drawEllipse(self._thumb_pos, self._thumb_radius, self._thumb_radius)

        # Inner highlight on thumb
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor(255, 255, 255, 40)))
        highlight_offset = self._thumb_radius * 0.3
        painter.drawEllipse(
            QPointF(
                self._thumb_pos.x() - highlight_offset,
                self._thumb_pos.y() - highlight_offset
            ),
            self._thumb_radius * 0.4,
            self._thumb_radius * 0.4
        )

        painter.end()

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position()
            dist = math.sqrt(
                (pos.x() - self._center.x()) ** 2 +
                (pos.y() - self._center.y()) ** 2
            )
            if dist <= self._base_radius:
                self._is_pressed = True
                self._under_mouse_drag = True
                self._update_thumb(pos)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._is_pressed and self._under_mouse_drag:
            self._update_thumb(event.position())

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton and self._under_mouse_drag:
            self._reset_thumb()

    def _update_thumb(self, pos: QPointF):
        """Update thumb position from mouse/touch position."""
        dx = pos.x() - self._center.x()
        dy = pos.y() - self._center.y()
        dist = math.sqrt(dx * dx + dy * dy)

        max_dist = self._base_radius - self._thumb_radius
        if dist > max_dist:
            dx = (dx / dist) * max_dist
            dy = (dy / dist) * max_dist

        self._thumb_pos = QPointF(
            self._center.x() + dx,
            self._center.y() + dy
        )

        # Normalize to -1..1
        self._dx = dx / max_dist if max_dist > 0 else 0
        self._dy = dy / max_dist if max_dist > 0 else 0

        self.direction_changed.emit(self._dx, self._dy)
        self.update()

    def keyPressEvent(self, event: QKeyEvent):
        key = event.text().upper()
        if key in self._key_states:
            self._key_states[key] = True
            event.accept()
        else:
            super().keyPressEvent(event)

    def keyReleaseEvent(self, event: QKeyEvent):
        key = event.text().upper()
        if key in self._key_states:
            self._key_states[key] = False
            if not any(self._key_states.values()) and not self._under_mouse_drag:
                self._reset_thumb()
            event.accept()
        else:
            super().keyReleaseEvent(event)

    def set_colors(self, bg: QColor = None, ring: QColor = None,
                   thumb: QColor = None, dead_zone: QColor = None):
        """Customize joystick colors."""
        if bg:
            self._bg_color = bg
        if ring:
            self._ring_color = ring
        if thumb:
            self._thumb_color = thumb
        if dead_zone:
            self._dead_zone_color = dead_zone
        self.update()

    def set_dead_zone(self, zone: float):
        """Set dead zone radius (0-1 normalized)."""
        self._dead_zone_radius = self._base_radius * max(0, min(1, zone))
        self.update()

    @property
    def direction(self):
        return (self._dx, self._dy)

    @property
    def is_active(self):
        return self._is_pressed

    # Prevent lint warning
    _under_mouse_drag = False
