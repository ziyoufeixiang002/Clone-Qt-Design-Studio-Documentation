package com.genymobile.scrcpy.video;

import com.genymobile.scrcpy.AndroidVersions;
import com.genymobile.scrcpy.Options;
import com.genymobile.scrcpy.control.PositionMapper;
import com.genymobile.scrcpy.display.DisplayInfo;
import com.genymobile.scrcpy.display.DisplayMonitor;
import com.genymobile.scrcpy.display.DisplayProperties;
import com.genymobile.scrcpy.display.DisplayPropertiesTracker;
import com.genymobile.scrcpy.display.DisplayResizeDebouncer;
import com.genymobile.scrcpy.model.NewDisplay;
import com.genymobile.scrcpy.model.Orientation;
import com.genymobile.scrcpy.model.Size;
import com.genymobile.scrcpy.opengl.AffineOpenGLFilter;
import com.genymobile.scrcpy.opengl.OpenGLFilter;
import com.genymobile.scrcpy.opengl.OpenGLRunner;
import com.genymobile.scrcpy.util.AffineMatrix;
import com.genymobile.scrcpy.util.Ln;
import com.genymobile.scrcpy.wrappers.ServiceManager;

import android.graphics.Rect;
import android.hardware.display.VirtualDisplay;
import android.os.Build;
import android.view.Surface;

import java.io.IOException;

public class NewDisplayCapture extends SurfaceCapture {

    // Internal fields copied from android.hardware.display.DisplayManager
    private static final int VIRTUAL_DISPLAY_FLAG_PUBLIC = android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
    private static final int VIRTUAL_DISPLAY_FLAG_PRESENTATION = android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION;
    private static final int VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY = android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;
    private static final int VIRTUAL_DISPLAY_FLAG_SUPPORTS_TOUCH = 1 << 6;
    private static final int VIRTUAL_DISPLAY_FLAG_ROTATES_WITH_CONTENT = 1 << 7;
    private static final int VIRTUAL_DISPLAY_FLAG_DESTROY_CONTENT_ON_REMOVAL = 1 << 8;
    private static final int VIRTUAL_DISPLAY_FLAG_SHOULD_SHOW_SYSTEM_DECORATIONS = 1 << 9;
    private static final int VIRTUAL_DISPLAY_FLAG_TRUSTED = 1 << 10;
    private static final int VIRTUAL_DISPLAY_FLAG_OWN_DISPLAY_GROUP = 1 << 11;
    private static final int VIRTUAL_DISPLAY_FLAG_ALWAYS_UNLOCKED = 1 << 12;
    private static final int VIRTUAL_DISPLAY_FLAG_TOUCH_FEEDBACK_DISABLED = 1 << 13;
    private static final int VIRTUAL_DISPLAY_FLAG_OWN_FOCUS = 1 << 14;
    private static final int VIRTUAL_DISPLAY_FLAG_DEVICE_DISPLAY_GROUP = 1 << 15;

    private final VirtualDisplayListener vdListener;
    private final NewDisplay newDisplay;

    private final DisplayMonitor displayMonitor = new DisplayMonitor();

    private AffineMatrix displayTransform;
    private AffineMatrix eventTransform;
    private OpenGLRunner glRunner;

    private Size mainDisplaySize;
    private int mainDisplayDpi;
    private final int displayImePolicy;
    private final Rect crop;
    private final boolean captureOrientationLocked;
    private final Orientation captureOrientation;
    private final float angle;
    private final boolean vdDestroyContent;
    private final boolean vdSystemDecorations;
    private final boolean flexDisplay;

    private VideoConstraints videoConstraints;

    private VirtualDisplay virtualDisplay;
    private Size videoSize;
    private Size displaySize; // the logical size of the display (including rotation)
    private Size physicalSize; // the physical size of the display (without rotation)

    private DisplayPropertiesTracker tracker;
    private DisplayResizeDebouncer debouncer;

    private int dpi;

    public NewDisplayCapture(VirtualDisplayListener vdListener, Options options) {
        this.vdListener = vdListener;
        this.newDisplay = options.getNewDisplay();
        assert newDisplay != null;
        this.displayImePolicy = options.getDisplayImePolicy();
        this.crop = options.getCrop();
        assert options.getCaptureOrientationLock() != null;
        this.captureOrientationLocked = options.getCaptureOrientationLock() != Orientation.Lock.Unlocked;
        this.captureOrientation = options.getCaptureOrientation();
        assert captureOrientation != null;
        this.angle = options.getAngle();
        this.vdDestroyContent = options.getVDDestroyContent();
        this.vdSystemDecorations = options.getVDSystemDecorations();
        this.flexDisplay = options.getFlexDisplay();
    }

    @Override
    protected void init(VideoConstraints videoConstraints) {
        setVideoConstraints(videoConstraints); // synchronized

        displaySize = newDisplay.getSize();
        dpi = newDisplay.getDpi();
        if (flexDisplay) {
            if (crop != null) {
                throw new IllegalArgumentException("Flex display does not support cropping");
            }

            tracker = new DisplayPropertiesTracker();
            debouncer = new DisplayResizeDebouncer(this::triggerResize);
            debouncer.start();

            // Hardcode default values if not defined
            if (displaySize == null) {
                displaySize = new Size(1280, 960);
            }
            if (dpi == 0) {
                dpi = 160;
            }
        } else if (displaySize == null || dpi == 0) {
            DisplayInfo displayInfo = ServiceManager.getDisplayManager().getDisplayInfo(0);
            if (displayInfo != null) {
                mainDisplaySize = displayInfo.getSize();
                if ((displayInfo.getRotation() % 2) != 0) {
                    mainDisplaySize = mainDisplaySize.rotate(); // Use the natural device orientation (at rotation 0), not the current one
                }
                mainDisplayDpi = displayInfo.getDpi();
            } else {
                Ln.w("Main display not found, fallback to 1920x1080 240dpi");
                mainDisplaySize = new Size(1920, 1080);
                mainDisplayDpi = 240;
            }
        }
    }

    @Override
    public void prepare() {
        int displayRotation;
        if (virtualDisplay == null) {
            if (flexDisplay) {
                assert displaySize != null;
                displaySize = displaySize.constrain(videoConstraints, false);
            } else {
                if (displaySize == null) {
                    assert !flexDisplay;
                    displaySize = mainDisplaySize;
                }

                // Align the physical display size to avoid unnecessary mismatches with the output size
                displaySize = displaySize.align(videoConstraints.getAlignment());
            }

            if (dpi == 0) {
                assert !flexDisplay;
                dpi = scaleDpi(mainDisplaySize, mainDisplayDpi, displaySize);
            }

            displayRotation = 0;
            // Set the current display properties to avoid an unnecessary capture reset
            displayMonitor.setSessionDisplayProperties(new DisplayProperties(displaySize, displayRotation));
        } else {
            DisplayInfo displayInfo = ServiceManager.getDisplayManager().getDisplayInfo(virtualDisplay.getDisplay().getDisplayId());
            dpi = displayInfo.getDpi();
            displayRotation = displayInfo.getRotation();
            displaySize = displayInfo.getSize();
            if (flexDisplay) {
                displaySize = displaySize.constrain(videoConstraints, false);
            } else {
                // Align the physical display size to avoid unnecessary mismatches with the output size
                displaySize = displaySize.align(videoConstraints.getAlignment());
            }
        }

        VideoFilter filter = new VideoFilter(displaySize);

        if (crop != null) {
            boolean transposed = (displayRotation % 2) != 0;
            filter.addCrop(crop, transposed);
        }

        filter.addOrientation(displayRotation, captureOrientationLocked, captureOrientation);
        filter.addAngle(angle);

        if (!flexDisplay) {
            Size outputSize = filter.getOutputSize();
            Size filteredSize = outputSize.constrain(videoConstraints);
            if (!filteredSize.equals(outputSize)) {
                filter.addResize(filteredSize);
            }
        }

        eventTransform = filter.getInverseTransform();

        // DisplayInfo gives the oriented size (so videoSize includes the display rotation)
        videoSize = filter.getOutputSize();

        // However, the virtual display video always remains in its original orientation, so it must be rotated manually.
        // This additional display rotation must not be included in the input events transform (the expected coordinates are already in the
        // physical display size)
        if ((displayRotation % 2) == 0) {
            physicalSize = displaySize;
        } else {
            physicalSize = displaySize.rotate();
        }
        VideoFilter displayFilter = new VideoFilter(physicalSize);
        displayFilter.addRotation(displayRotation);
        AffineMatrix displayRotationMatrix = displayFilter.getInverseTransform();

        // Take care of multiplication order:
        //   displayTransform = (FILTER_MATRIX * DISPLAY_FILTER_MATRIX)⁻¹
        //                    = DISPLAY_FILTER_MATRIX⁻¹ * FILTER_MATRIX⁻¹
        //                    = displayRotationMatrix * eventTransform
        displayTransform = AffineMatrix.multiplyAll(displayRotationMatrix, eventTransform);
    }

    public void startNew(Surface surface) {
        try {
            int flags = VIRTUAL_DISPLAY_FLAG_PUBLIC
                    | VIRTUAL_DISPLAY_FLAG_PRESENTATION
                    | VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
                    | VIRTUAL_DISPLAY_FLAG_SUPPORTS_TOUCH
                    | VIRTUAL_DISPLAY_FLAG_ROTATES_WITH_CONTENT;
            if (vdDestroyContent) {
                flags |= VIRTUAL_DISPLAY_FLAG_DESTROY_CONTENT_ON_REMOVAL;
            }
            if (vdSystemDecorations) {
                flags |= VIRTUAL_DISPLAY_FLAG_SHOULD_SHOW_SYSTEM_DECORATIONS;
            }
            if (Build.VERSION.SDK_INT >= AndroidVersions.API_33_ANDROID_13) {
                flags |= VIRTUAL_DISPLAY_FLAG_TRUSTED
                        | VIRTUAL_DISPLAY_FLAG_OWN_DISPLAY_GROUP
                        | VIRTUAL_DISPLAY_FLAG_ALWAYS_UNLOCKED
                        | VIRTUAL_DISPLAY_FLAG_TOUCH_FEEDBACK_DISABLED;
                if (Build.VERSION.SDK_INT >= AndroidVersions.API_34_ANDROID_14) {
                    flags |= VIRTUAL_DISPLAY_FLAG_OWN_FOCUS
                            | VIRTUAL_DISPLAY_FLAG_DEVICE_DISPLAY_GROUP;
                }
            }
            VirtualDisplay vd = ServiceManager.getDisplayManager()
                    .createNewVirtualDisplay("scrcpy", displaySize.getWidth(), displaySize.getHeight(), dpi, surface, flags);
            setCurrentVirtualDisplay(vd); // used for client resize
            int virtualDisplayId = vd.getDisplay().getDisplayId();
            Ln.i("New display: " + displaySize.getWidth() + "x" + displaySize.getHeight() + "/" + dpi + " (id=" + virtualDisplayId + ")");

            if (displayImePolicy != -1) {
                ServiceManager.getWindowManager().setDisplayImePolicy(virtualDisplayId, displayImePolicy);
            }

            displayMonitor.start(virtualDisplayId, (props) -> {
                int reason;
                if (flexDisplay) {
                    boolean isClientResize = tracker.onChanged(props);
                    if (isClientResize) {
                        reason = CaptureControl.RESET_REASON_CLIENT_RESIZED;
                    } else {
                        reason = CaptureControl.RESET_REASON_DISPLAY_PROPERTIES_CHANGED;
                        // Display properties have changed, cancel pending client resize requests
                        debouncer.cancelResize();
                    }
                } else {
                    reason = CaptureControl.RESET_REASON_DISPLAY_PROPERTIES_CHANGED;
                }
                getCaptureControl().reset(reason);
            });
        } catch (Exception e) {
            Ln.e("Could not create display", e);
            throw new AssertionError("Could not create display");
        }
    }

    @Override
    public void start(Surface surface) throws IOException {
        if (displayTransform != null) {
            assert glRunner == null;
            OpenGLFilter glFilter = new AffineOpenGLFilter(displayTransform);
            glRunner = new OpenGLRunner(glFilter);
            surface = glRunner.start(physicalSize, videoSize, surface);
        }

        if (virtualDisplay == null) {
            startNew(surface);
        } else {
            virtualDisplay.setSurface(surface);
        }

        if (vdListener != null) {
            PositionMapper positionMapper = PositionMapper.create(videoSize, eventTransform, displaySize);
            vdListener.onNewVirtualDisplay(virtualDisplay.getDisplay().getDisplayId(), positionMapper);
        }
    }

    @Override
    public void stop() {
        if (glRunner != null) {
            glRunner.stopAndRelease();
            glRunner = null;
        }
    }

    @Override
    public void release() {
        displayMonitor.stopAndRelease();

        if (debouncer != null) {
            debouncer.stop();
        }

        if (virtualDisplay != null) {
            // synchronized with triggerResize()
            synchronized (this) {
                virtualDisplay.release();
                setCurrentVirtualDisplay(null);
            }
        }
    }

    @Override
    public Size getSize() {
        return videoSize;
    }

    @Override
    protected boolean applyNewVideoConstraints(VideoConstraints videoConstraints) {
        setVideoConstraints(videoConstraints); // with synchronization
        return true;
    }

    private static int scaleDpi(Size initialSize, int initialDpi, Size size) {
        int den = initialSize.getMax();
        int num = size.getMax();
        return initialDpi * num / den;
    }

    public void requestResize(int width, int height) {
        if (!flexDisplay) {
            throw new IllegalStateException("Cannot resize a non-flex display");
        }

        VideoConstraints constraints = getVideoConstraints(); // synchronized
        Size newSize = new Size(width, height).constrain(constraints, false);
        if (Ln.isEnabled(Ln.Level.VERBOSE)) {
            Ln.v(getClass().getSimpleName() + ": requestResize(" + width + ", " + height + ")");
            Ln.v(getClass().getSimpleName() + ": constrained size = " + newSize);
        }

        debouncer.requestResize(newSize);
    }

    private synchronized void setCurrentVirtualDisplay(VirtualDisplay virtualDisplay) {
        this.virtualDisplay = virtualDisplay;
    }

    private synchronized VideoConstraints getVideoConstraints() {
        return videoConstraints;
    }

    private synchronized void setVideoConstraints(VideoConstraints videoConstraints) {
        this.videoConstraints = videoConstraints;
    }

    private synchronized void triggerResize(Size size) {
        if (virtualDisplay != null) {
            size = size.constrain(videoConstraints); // in case the constraints have changed
            int displayId = virtualDisplay.getDisplay().getDisplayId();
            DisplayInfo displayInfo = ServiceManager.getDisplayManager().getDisplayInfo(displayId);
            int displayRotation = displayInfo.getRotation();
            if (captureOrientation.isSwap()) {
                size = size.rotate();
            }
            tracker.pushClientRequest(new DisplayProperties(size, displayRotation));

            // Although the display size (as detected by the DisplayMonitor) is rotated, the virtual display itself is not
            Size vdSize = (displayRotation % 2) == 0 ? size : size.rotate();
            virtualDisplay.resize(vdSize.getWidth(), vdSize.getHeight(), dpi);
        }
    }
}
