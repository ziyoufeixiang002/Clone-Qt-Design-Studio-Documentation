# -*- mode: python ; coding: utf-8 -*-
# Scrcpy GamePad PyInstaller Spec File

block_cipher = None

a = Analysis(
    ['/root/.openclaw/workspace/scrcpy-gamepad/main.py'],
    pathex=['/root/.openclaw/workspace/scrcpy-gamepad'],
    binaries=[],
    datas=[
        ('/root/.openclaw/workspace/scrcpy-gamepad/src/config', 'src/config'),
        ('/root/.openclaw/workspace/scrcpy-gamepad/src/core', 'src/core'),
        ('/root/.openclaw/workspace/scrcpy-gamepad/src/gui', 'src/gui'),
    ],
    hiddenimports=[
        'PyQt6.QtWidgets', 'PyQt6.QtCore', 'PyQt6.QtGui',
        'src.core.adb_manager', 'src.core.touch_injector',
        'src.core.key_mapper', 'src.core.joystick_engine',
        'src.gui.main_window', 'src.gui.joystick_widget',
        'src.gui.key_editor_dialog', 'src.gui.screen_overlay',
        'src.config.settings', 'src.config.default_profiles',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'matplotlib', 'numpy', 'scipy'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='scrcpy-gamepad',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # Set True for console version
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='scrcpy-gamepad',
)
