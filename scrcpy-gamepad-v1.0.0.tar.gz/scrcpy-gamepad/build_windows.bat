@echo off
REM Scrcpy GamePad - Windows Build Script
REM Builds standalone executable using PyInstaller

echo ============================================
echo  Scrcpy GamePad - Windows Build
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.9+ and add to PATH.
    pause
    exit /b 1
)

REM Install/upgrade dependencies
echo [1/4] Installing dependencies...
pip install --upgrade pip
pip install PyQt6>=6.5.0 PyQt6-sip>=13.5.0 PyInstaller>=6.0.0
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

REM Clean previous builds
echo [2/4] Cleaning previous builds...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
if exist *.spec del /q *.spec

REM Build windowed version
echo [3/4] Building windowed version...
python build.py build
if errorlevel 1 (
    echo ERROR: Build failed.
    pause
    exit /b 1
)

REM Generate spec file
echo [4/4] Generating spec file...
python build.py spec

echo.
echo ============================================
echo  Build Complete!
echo ============================================
echo.
echo Output: dist\scrcpy-gamepad\
echo.
echo To create a portable package:
echo   1. Copy dist\scrcpy-gamepad\ to your target machine
echo   2. Ensure adb.exe is in PATH or same folder
echo   3. Run scrcpy-gamepad.exe
echo.
pause
