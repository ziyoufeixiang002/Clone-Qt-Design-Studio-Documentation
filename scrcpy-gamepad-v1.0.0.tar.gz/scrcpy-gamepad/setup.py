"""Setup script for scrcpy-gamepad."""
from setuptools import setup, find_packages

setup(
    name="scrcpy-gamepad",
    version="1.0.0",
    description="Android game controller mapping tool based on scrcpy",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Scrcpy GamePad Contributors",
    license="Apache-2.0",
    python_requires=">=3.9",
    install_requires=[
        "PyQt6>=6.5.0",
    ],
    extras_require={
        "build": ["PyInstaller>=6.0.0"],
    },
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "scrcpy-gamepad=main:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Games/Entertainment",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
    ],
)
