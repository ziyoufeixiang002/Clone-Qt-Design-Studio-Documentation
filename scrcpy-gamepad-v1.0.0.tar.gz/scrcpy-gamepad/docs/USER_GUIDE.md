# 用户指南 - Scrcpy GamePad

## 简介

Scrcpy GamePad 是一款基于 scrcpy 的 Android 游戏投屏+按键映射工具。它可以将手机屏幕投射到电脑上，并将键盘/鼠标操作映射为手机触控操作，让你用电脑玩手机游戏。

## 功能特性

- 🎮 **虚拟摇杆** - WASD 映射为方向控制，支持8方向和平滑移动
- 🖱️ **鼠标映射** - 鼠标点击/移动映射为触控操作
- ⌨️ **按键映射** - 任意键盘按键映射为屏幕点击/滑动
- 👆 **多点触控** - 支持双指缩放、多点同时点击
- 📐 **可视化编辑器** - 图形化配置按键映射位置
- 🎯 **屏幕取点** - 截图后直接点击选择坐标
- 📦 **预设配置** - 内置 FPS/MOBA/竞速游戏配置
- 🔄 **低延迟** - 使用 sendevent 直接注入，延迟 <5ms

## 安装说明

### 方式一：直接运行（需要 Python 环境）

1. 安装 Python 3.9+
   - Windows: 从 https://python.org 下载安装
   - Linux: `sudo apt install python3 python3-pip`
   - macOS: `brew install python3`

2. 安装依赖
   ```bash
   pip install PyQt6>=6.5.0
   ```

3. 安装 scrcpy
   - Windows: `scoop install scrcpy` 或从 GitHub 下载
   - Linux: `sudo apt install scrcpy`
   - macOS: `brew install scrcpy`

4. 安装 ADB
   - Windows: 下载 Android SDK Platform Tools
   - Linux: `sudo apt install adb`
   - macOS: `brew install android-platform-tools`

5. 运行程序
   ```bash
   python main.py
   ```

### 方式二：使用打包好的可执行文件

1. 下载发布包
2. 解压到任意目录
3. 确保 `adb` 在系统 PATH 中或放在同一目录
4. 运行 `scrcpy-gamepad.exe`（Windows）或 `./scrcpy-gamepad`（Linux/macOS）

## 连接设备

### USB 连接

1. 在手机上开启 **开发者选项**
   - 设置 → 关于手机 → 连续点击"版本号"7次
2. 开启 **USB 调试**
   - 设置 → 开发者选项 → USB 调试
3. 用 USB 数据线连接手机和电脑
4. 在手机上点击"允许 USB 调试"
5. 在 Scrcpy GamePad 中点击 **Refresh Devices**
6. 选择设备，点击 **Connect**

### 无线连接（WiFi）

1. 先用 USB 连接设备
2. 开启 TCP/IP 模式：
   ```bash
   adb tcpip 5555
   ```
3. 断开 USB 线
4. 在地址栏输入手机 IP 地址和端口，如 `192.168.1.100:5555`
5. 点击 **Connect**

> 💡 手机 IP 地址：设置 → 关于手机 → 状态 → IP 地址

## 配置按键映射

### 使用预设配置

1. 在左侧面板的 **Game Profile** 下拉菜单中选择：
   - **FPS** - 适合 PUBG、使命召唤手游等射击游戏
   - **MOBA** - 适合 Mobile Legends、英雄联盟手游等
   - **Racing** - 适合 Asphalt、马里奥赛车等竞速游戏

2. 预设会自动加载对应的按键映射

### 自定义按键映射

1. 点击右侧的 **Edit Mappings** 按钮
2. 在编辑器中选择映射类型：

#### 点击 (Tap)
- 按键：按下要映射的键
- X, Y：点击位置（0-1 归一化坐标）
- 例：将 Space 映射到屏幕右下角 (0.85, 0.75)

#### 滑动 (Swipe)
- 按键：触发键
- 起点/终点：滑动的起点和终点坐标
- 持续时间：滑动耗时（毫秒）

#### 虚拟摇杆 (Joystick)
- 方向键：上/下/左/右
- 中心点：摇杆中心在屏幕上的位置
- 半径：摇杆活动范围

#### 长按 (Long Press)
- 按键：触发键
- 坐标：长按位置
- 持续时间：长按时长

#### 多点点击 (Multi Tap)
- 按键：触发键
- 点列表：同时点击的多个坐标

### 屏幕取点

1. 先连接设备并启动投屏
2. 在编辑器中切换到 **Screen Picker** 标签
3. 点击 **Take Screenshot** 截取当前屏幕
4. 点击 **Pick Coordinates**
5. 在截图上点击要选择的位置
6. 坐标会自动填充到对应的输入框

## 使用虚拟摇杆

### 键盘控制

- **W** - 上
- **A** - 左
- **S** - 下
- **D** - 右
- 支持对角线方向（同时按两个键）

### 鼠标控制

- 在左下角的摇杆组件上拖拽
- 松开鼠标自动回中

### 调整摇杆位置

在配置文件或编辑器中修改：
- `center_x` - 水平位置（0=最左，1=最右）
- `center_y` - 垂直位置（0=最上，1=最下）
- `radius` - 活动半径

## 快捷键

| 快捷键 | 功能 |
|--------|------|
| F11 | 全屏切换 |
| F12 | 显示/隐藏按键覆盖层 |
| ESC | 释放鼠标捕获 |
| Ctrl+O | 加载配置文件 |
| Ctrl+S | 保存配置文件 |
| Ctrl+Q | 退出程序 |
| Ctrl+P | 截图 |

## 常见问题

### Q: 连接设备失败？

1. 确认 USB 调试已开启
2. 检查 USB 数据线是否支持数据传输（非仅充电线）
3. 运行 `adb devices` 确认设备已识别
4. 尝试重启 ADB：`adb kill-server && adb start-server`

### Q: 触控操作没有反应？

1. 确认触控设备路径正确
   - 运行 `adb shell getevent -pl` 查看
   - 在设置中修改 `sendevent_device`
2. 尝试切换到 input 命令模式（关闭 sendevent）
3. 某些游戏可能需要特殊权限

### Q: 延迟很高？

1. 使用 USB 连接而非 WiFi
2. 确认 sendevent 模式已启用
3. 降低 scrcpy 的分辨率和码率
4. 关闭不必要的后台程序

### Q: 按键映射位置不准？

1. 使用屏幕取点功能精确定位
2. 使用归一化坐标（0-1）而非像素坐标
3. 确认设备分辨率设置正确

### Q: 如何支持多点触控？

多点触控使用 sendevent 协议直接注入，支持：
- 双指缩放（pinch）
- 多点同时点击
- 最多10个触控点

### Q: 某些游戏不识别输入？

部分游戏使用了反作弊系统，可能检测到非标准输入。可以尝试：
1. 使用 HID 模式（需要 root）
2. 使用 scrcpy 的 UHID 功能
3. 调整输入延迟参数

## 配置文件位置

- **设置文件**: `~/.scrcpy-gamepad/settings.json`
- **配置文件**: 用户自定义目录（通过"保存配置"选择）
- **锁文件**: `~/.scrcpy-gamepad/app.lock`

## 预设配置详情

### FPS 配置
| 按键 | 功能 |
|------|------|
| WASD | 移动 |
| 鼠标左键 | 开火 |
| 鼠标右键 | 瞄准/开镜 |
| Space | 跳跃 |
| R | 换弹 |
| E | 互动 |
| F | 下蹲 |
| G | 手雷 |
| C | 趴下 |
| Z | 开镜 |
| 1/2 | 切换武器 |
| Tab | 背包 |
| M | 地图 |

### MOBA 配置
| 按键 | 功能 |
|------|------|
| WASD | 移动 |
| Q/W/E/R | 技能 1-4 |
| Space | 普通攻击 |
| F | 闪现 |
| B | 回城 |
| Tab | 计分板 |

### 竞速配置
| 按键 | 功能 |
|------|------|
| W | 加速 |
| S | 刹车 |
| A/D | 左转/右转 |
| Space | 氮气加速 |
| E | 道具 |
| F | 漂移 |

## 技术支持

- 问题反馈：GitHub Issues
- 技术文档：docs/TECHNICAL.md
- 源代码：基于 scrcpy 二次开发
