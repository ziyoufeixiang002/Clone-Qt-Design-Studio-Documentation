# 技术文档 - Scrcpy GamePad

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                    Scrcpy GamePad 应用                       │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │  GUI 层 (PyQt6)│  │ 按键映射引擎  │  │  虚拟摇杆引擎    │   │
│  │  - 主窗口      │  │  - KeyMapper │  │  - JoystickEngine│   │
│  │  - 摇杆组件    │  │  - 映射配置   │  │  - WASD→触摸     │   │
│  │  - 编辑器对话框│  │  - 事件分发   │  │  - 平滑插值      │   │
│  │  - 屏幕覆盖层  │  │              │  │  - 死区处理       │   │
│  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘   │
│         │                 │                    │             │
│  ┌──────┴─────────────────┴────────────────────┴──────────┐  │
│  │              触控注入器 (TouchInjector)                  │  │
│  │  - 坐标归一化 (0-1 → 像素)                              │  │
│  │  - sendevent 低延迟注入                                 │  │
│  │  - input 命令兼容模式                                   │  │
│  │  - 事件批处理 (120Hz)                                   │  │
│  │  - 多点触控支持                                         │  │
│  └──────────────────────────┬─────────────────────────────┘  │
│                             │                                │
│  ┌──────────────────────────┴─────────────────────────────┐  │
│  │              ADB 管理器 (ADBManager)                    │  │
│  │  - 设备连接/断开                                         │  │
│  │  - Shell 命令执行                                        │  │
│  │  - 自动重连                                              │  │
│  │  - 线程安全                                              │  │
│  │  - sendevent 批量发送                                    │  │
│  └──────────────────────────┬─────────────────────────────┘  │
│                             │                                │
├─────────────────────────────┼────────────────────────────────┤
│                             │                                │
│  ┌──────────────────────────┴─────────────────────────────┐  │
│  │              scrcpy (屏幕镜像后端)                       │  │
│  │  - 视频流解码 (H.264/H.265)                             │  │
│  │  - SDL3 窗口渲染                                        │  │
│  │  - 低延迟显示 (<50ms)                                   │  │
│  └──────────────────────────┬─────────────────────────────┘  │
│                             │                                │
├─────────────────────────────┼────────────────────────────────┤
│                             │        USB / TCP/IP            │
│                    ┌────────┴────────┐                       │
│                    │   Android 设备   │                       │
│                    │  scrcpy-server  │                       │
│                    └─────────────────┘                       │
└─────────────────────────────────────────────────────────────┘
```

## 组件详解

### 1. ADBManager (`src/core/adb_manager.py`)

ADB 连接管理器，负责与 Android 设备通信。

**核心功能：**
- `connect(address)` - 通过 USB 或 TCP/IP 连接设备
- `send_shell(cmd)` - 执行 ADB Shell 命令（线程安全）
- `send_sendevent_batch(events)` - 批量发送 sendevent 事件
- `send_multi_touch(points, action)` - 多点触控注入
- `screenshot()` - 截图并拉取到本地
- 自动重连机制（最多3次重试）

**触控设备发现：**
通过 `getevent -pl` 命令自动发现触控输入设备路径（如 `/dev/input/event2`）。

### 2. TouchInjector (`src/core/touch_injector.py`)

高层触控注入引擎，封装 ADBManager。

**两种注入模式：**
1. **sendevent 模式**（低延迟）：直接写入 Linux 输入子系统
2. **input 命令模式**（兼容性好）：使用 Android input 框架

**坐标归一化：**
```
输入: 0.0 ~ 1.0 (归一化坐标)
输出: 0 ~ 屏幕宽度/高度 (像素坐标)
```

**支持的操作：**
- `inject_tap(x, y)` - 点击
- `inject_swipe(x1, y1, x2, y2, duration)` - 滑动
- `inject_long_press(x, y, duration)` - 长按
- `inject_pinch(cx, cy, ds, de, duration)` - 双指缩放
- `inject_multi_tap(points)` - 多点同时点击
- `touch_down/move_up` - 连续触控（用于摇杆）

### 3. KeyMapper (`src/core/key_mapper.py`)

按键映射引擎。

**映射类型 (MappingAction)：**
| 类型 | 说明 | 参数 |
|------|------|------|
| TAP | 点击 | x, y |
| SWIPE | 滑动 | x1, y1, x2, y2, duration_ms |
| JOYSTICK | 虚拟摇杆 | center_x, center_y, radius, direction |
| LONG_PRESS | 长按 | x, y, duration_ms |
| MULTI_TAP | 多点点击 | points: [(x,y), ...] |
| COMBO | 组合键 | actions: [{action, params, delay}] |

**修饰键支持：**
支持 Shift/Ctrl/Alt + 按键的组合映射。

### 4. JoystickEngine (`src/core/joystick_engine.py`)

虚拟摇杆引擎，将 WASD 映射为连续触控滑动。

**工作原理：**
1. 监听 WASD 按键状态
2. 计算方向向量（支持8方向+对角线归一化）
3. 应用死区过滤
4. 平滑插值（可配置平滑度）
5. 以 60Hz 频率发送 touch_move 事件

**参数：**
- `center_x, center_y` - 摇杆中心位置（归一化）
- `radius` - 最大滑动半径（归一化）
- `dead_zone` - 死区大小（0-0.5）
- `smoothing` - 平滑系数（0=瞬时, 1=极平滑）

### 5. GUI 组件

**MainWindow** - 主窗口
- 设备连接面板（IP输入、设备列表、状态指示）
- 屏幕镜像区域（scrcpy 窗口引用）
- 按键映射列表（显示/编辑/删除）
- 菜单栏和工具栏
- 状态栏（连接状态、延迟、输入频率）

**JoystickWidget** - 虚拟摇杆可视化
- 圆形底座 + 可拖拽摇杆
- 支持鼠标拖拽和键盘 WASD
- 死区可视化
- 发射 `direction_changed(dx, dy)` 信号

**KeyEditorDialog** - 按键映射编辑器
- 6个标签页：点击、滑动、摇杆、长按、多点点击、屏幕取点
- "录制按键"模式：按下任意键自动填充
- 屏幕截图取点功能
- 预设配置加载

**ScreenOverlay** - 屏幕覆盖层
- 半透明浮动窗口
- 彩色圆点标记映射位置
- 按动作类型着色
- 脉冲动画效果
- F12 快捷键切换

## 数据流

```
用户按键 → QKeyEvent → MainWindow.keyPressEvent()
    ↓
KeyMapper.process_key_event(key, pressed)
    ↓ 查找映射
    ├── TAP → TouchInjector.inject_tap(x, y)
    │           → ADBManager.send_sendevent_batch()
    │               → adb shell sendevent /dev/input/eventX ...
    │
    ├── JOYSTICK → JoystickEngine.update_from_keys()
    │               → 计算方向向量
    │               → TouchInjector.touch_move(x, y)
    │                   → ADBManager.send_sendevent_batch()
    │
    ├── SWIPE → TouchInjector.inject_swipe()
    │           → 插值移动 + sendevent
    │
    └── LONG_PRESS → TouchInjector.inject_long_press()
                     → touch_down + sleep + touch_up
```

## sendevent 协议详解

Linux 多点触控协议 (Protocol B)：

```
# 触控按下
sendevent /dev/input/event2 3 57 <tracking_id>   # ABS_MT_TRACKING_ID
sendevent /dev/input/event2 3 53 <x>              # ABS_MT_POSITION_X
sendevent /dev/input/event2 3 54 <y>              # ABS_MT_POSITION_Y
sendevent /dev/input/event2 3 48 <pressure>       # ABS_MT_TOUCH_MAJOR
sendevent /dev/input/event2 0 2 0                 # SYN_MT_REPORT
sendevent /dev/input/event2 0 0 0                 # SYN_REPORT

# 触控移动
sendevent /dev/input/event2 3 57 <tracking_id>
sendevent /dev/input/event2 3 53 <new_x>
sendevent /dev/input/event2 3 54 <new_y>
sendevent /dev/input/event2 0 2 0
sendevent /dev/input/event2 0 0 0

# 触控释放
sendevent /dev/input/event2 3 57 -1               # tracking_id = -1
sendevent /dev/input/event2 0 2 0
sendevent /dev/input/event2 0 0 0
```

**事件类型：**
- `0` = EV_SYN（同步事件）
- `3` = EV_ABS（绝对坐标事件）

**事件代码：**
- `57` = ABS_MT_TRACKING_ID（触控点ID）
- `53` = ABS_MT_POSITION_X（X坐标）
- `54` = ABS_MT_POSITION_Y（Y坐标）
- `48` = ABS_MT_TOUCH_MAJOR（触控面积）

## 线程模型

```
主线程 (Qt GUI)
    ├── 键盘/鼠标事件处理
    ├── GUI 更新
    └── 状态栏定时器

JoystickEngine 线程 (daemon)
    └── 60Hz 循环发送 touch_move 事件

TouchInjector 批处理线程 (daemon)
    └── 120Hz 循环处理事件队列

Scrcpy 子进程
    └── 独立进程处理视频解码和渲染
```

## 性能优化

1. **sendevent vs input 命令**
   - sendevent: ~1-3ms 延迟（直接内核调用）
   - input 命令: ~20-50ms 延迟（需要 Java VM 启动）
   - 默认使用 sendevent 模式

2. **命令批处理**
   - 多个 sendevent 合并到一次 adb shell 调用
   - 减少 adb 进程创建开销

3. **坐标缓存**
   - 设备分辨率缓存，避免重复查询
   - 触控设备路径缓存

4. **平滑插值**
   - 摇杆移动使用线性插值，避免突变
   - 可配置平滑系数

## 配置文件格式

```json
{
  "version": "1.0",
  "metadata": {
    "name": "FPS Profile",
    "game": "PUBG Mobile"
  },
  "mappings": {
    "W": {
      "key": "W",
      "action": "joystick",
      "params": {
        "center_x": 0.15,
        "center_y": 0.7,
        "radius": 0.08,
        "direction": "up"
      },
      "group": "movement"
    },
    "Space": {
      "key": "Space",
      "action": "tap",
      "params": {
        "x": 0.85,
        "y": 0.75,
        "coordinate_mode": "normalized"
      },
      "description": "Jump"
    }
  },
  "joystick": {
    "enabled": true,
    "center_x": 0.15,
    "center_y": 0.7,
    "radius": 0.08,
    "dead_zone": 0.15
  }
}
```

## 依赖项

| 依赖 | 版本 | 用途 |
|------|------|------|
| Python | ≥3.9 | 运行时 |
| PyQt6 | ≥6.5.0 | GUI 框架 |
| PyInstaller | ≥6.0.0 | 打包工具 |
| scrcpy | ≥2.0 | 屏幕镜像 |
| adb | 任意 | 设备通信 |

## 扩展点

### 添加新的映射类型

1. 在 `MappingAction` 枚举中添加新类型
2. 在 `KeyMapper._execute_action()` 中添加处理逻辑
3. 在 `KeyEditorDialog` 中添加对应的编辑标签页
4. 在 `ScreenOverlay.ACTION_COLORS` 中添加颜色

### 自定义触控协议

修改 `TouchInjector` 中的 `sendevent` 事件序列，适配不同的 Android 设备或输入设备。

### 添加游戏手柄支持

在 `MainWindow` 中添加 `QGamepad` 事件处理，映射手柄轴和按钮到 `KeyMapper`。
