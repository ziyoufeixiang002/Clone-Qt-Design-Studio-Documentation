# Scrcpy GamePad - Android 游戏投屏按键映射工具

[English](#english) | [中文](#中文)

---

## 中文

基于 [scrcpy](https://github.com/Genymobile/scrcpy) 的二次开发项目，将手机游戏投屏到电脑，并用键盘鼠标操控。

### ✨ 功能特性

- 🎮 **虚拟摇杆** - WASD 控制方向，支持8方向+对角线
- 🖱️ **鼠标映射** - 鼠标点击/移动 → 触控操作
- ⌨️ **按键映射** - 任意按键 → 屏幕点击/滑动/长按
- 👆 **多点触控** - 双指缩放、多点同时点击
- 📐 **可视化编辑器** - 图形化配置，截图取点
- 📦 **游戏预设** - FPS / MOBA / 竞速 一键切换
- 🔄 **超低延迟** - sendevent 直注入，<5ms 响应
- 🎯 **屏幕覆盖层** - 实时显示映射位置

### 🚀 快速开始

```bash
# 1. 安装依赖
pip install PyQt6>=6.5.0

# 2. 确保 adb 和 scrcpy 已安装
adb version
scrcpy --version

# 3. 连接手机并运行
python main.py
```

### 📦 打包为可执行文件

```bash
# Windows
build_windows.bat

# 或手动打包
pip install PyInstaller
python build.py build
```

### 📖 文档

- [用户指南](docs/USER_GUIDE.md) - 安装、配置、使用教程
- [技术文档](docs/TECHNICAL.md) - 架构设计、协议详解

---

## English

A secondary development based on [scrcpy](https://github.com/Genymobile/scrcpy) for playing Android games on PC with keyboard and mouse mapping.

### ✨ Features

- 🎮 **Virtual Joystick** - WASD movement with 8-direction support
- 🖱️ **Mouse Mapping** - Mouse clicks/moves → touch events
- ⌨️ **Key Mapping** - Any key → screen tap/swipe/long press
- 👆 **Multi-touch** - Pinch zoom, simultaneous multi-point taps
- 📐 **Visual Editor** - GUI-based mapping with screen coordinate picker
- 📦 **Game Presets** - FPS / MOBA / Racing one-click profiles
- 🔄 **Low Latency** - sendevent injection, <5ms response
- 🎯 **Screen Overlay** - Real-time mapping position indicators

### 🚀 Quick Start

```bash
# 1. Install dependencies
pip install PyQt6>=6.5.0

# 2. Ensure adb and scrcpy are installed
adb version
scrcpy --version

# 3. Connect device and run
python main.py
```

### 📦 Build Executable

```bash
# Windows
build_windows.bat

# Or manually
pip install PyInstaller
python build.py build
```

### 📖 Documentation

- [User Guide](docs/USER_GUIDE.md) - Installation, configuration, usage
- [Technical Doc](docs/TECHNICAL.md) - Architecture, protocols

---

## 项目结构

```
scrcpy-gamepad/
├── main.py                     # 入口文件
├── build.py                    # 打包脚本
├── build_windows.bat           # Windows 打包批处理
├── scrcpy-gamepad.spec         # PyInstaller 配置
├── requirements.txt            # Python 依赖
├── setup.py                    # pip 安装配置
├── src/
│   ├── core/                   # 核心引擎
│   │   ├── adb_manager.py      # ADB 连接管理
│   │   ├── touch_injector.py   # 触控注入器
│   │   ├── key_mapper.py       # 按键映射引擎
│   │   └── joystick_engine.py  # 虚拟摇杆引擎
│   ├── gui/                    # GUI 组件
│   │   ├── main_window.py      # 主窗口
│   │   ├── joystick_widget.py  # 摇杆可视化组件
│   │   ├── key_editor_dialog.py# 按键编辑器
│   │   └── screen_overlay.py   # 屏幕覆盖层
│   └── config/                 # 配置
│       ├── settings.py         # 应用设置
│       └── default_profiles.py # 默认游戏配置
├── docs/
│   ├── TECHNICAL.md            # 技术文档
│   └── USER_GUIDE.md           # 用户指南
└── scrcpy/                     # scrcpy 源码（参考）
```

## License

Apache License 2.0 (同 scrcpy)
