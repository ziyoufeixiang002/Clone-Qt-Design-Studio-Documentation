#!/usr/bin/env python3
"""
Build script for Scrcpy GamePad.
Creates standalone executables using PyInstaller.
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path


PROJECT_ROOT = Path(__file__).parent
DIST_DIR = PROJECT_ROOT / "dist"
BUILD_DIR = PROJECT_ROOT / "build"
APP_NAME = "scrcpy-gamepad"


def clean():
    """Remove build artifacts."""
    for d in [DIST_DIR, BUILD_DIR]:
        if d.exists():
            shutil.rmtree(d)
            print(f"Cleaned: {d}")
    for spec in PROJECT_ROOT.glob("*.spec"):
        if spec.name != f"{APP_NAME}.spec":
            spec.unlink()
            print(f"Removed: {spec}")


def build(windowed: bool = True, one_file: bool = False):
    """Build the executable using PyInstaller."""
    args = [
        sys.executable, "-m", "PyInstaller",
        "--name", APP_NAME,
        "--clean",
        "--noconfirm",
    ]

    if windowed:
        args.append("--windowed")
    else:
        args.append("--console")

    if one_file:
        args.append("--onefile")
    else:
        args.append("--onedir")

    # Add data files
    data_dirs = [
        ("src/config", "src/config"),
        ("src/core", "src/core"),
        ("src/gui", "src/gui"),
    ]
    for src, dst in data_dirs:
        src_path = PROJECT_ROOT / src
        if src_path.exists():
            args.extend(["--add-data", f"{src_path}{os.pathsep}{dst}"])

    # Hidden imports
    hidden_imports = [
        "PyQt6.QtWidgets",
        "PyQt6.QtCore",
        "PyQt6.QtGui",
        "src.core.adb_manager",
        "src.core.touch_injector",
        "src.core.key_mapper",
        "src.core.joystick_engine",
        "src.gui.main_window",
        "src.gui.joystick_widget",
        "src.gui.key_editor_dialog",
        "src.gui.screen_overlay",
        "src.config.settings",
        "src.config.default_profiles",
    ]
    for hi in hidden_imports:
        args.extend(["--hidden-import", hi])

    # Icon
    icon_path = PROJECT_ROOT / "assets" / "icon.ico"
    if icon_path.exists():
        args.extend(["--icon", str(icon_path)])

    # Entry point
    args.append(str(PROJECT_ROOT / "main.py"))

    print(f"Building {'windowed' if windowed else 'console'} version...")
    print(f"Command: {' '.join(args)}")

    result = subprocess.run(args, cwd=PROJECT_ROOT)
    if result.returncode == 0:
        print(f"\nBuild successful! Output in: {DIST_DIR / APP_NAME}")
    else:
        print(f"\nBuild failed with return code {result.returncode}")
        sys.exit(1)


def build_all():
    """Build both windowed and console versions."""
    clean()

    # Windowed version
    build(windowed=True, one_file=False)

    # Rename output
    windowed_dir = DIST_DIR / APP_NAME
    if windowed_dir.exists():
        renamed = DIST_DIR / f"{APP_NAME}-gui"
        if renamed.exists():
            shutil.rmtree(renamed)
        windowed_dir.rename(renamed)
        print(f"Windowed build: {renamed}")

    # Console version
    build(windowed=False, one_file=False)

    console_dir = DIST_DIR / APP_NAME
    if console_dir.exists():
        renamed = DIST_DIR / f"{APP_NAME}-console"
        if renamed.exists():
            shutil.rmtree(renamed)
        console_dir.rename(renamed)
        print(f"Console build: {renamed}")

    print("\n=== Build Complete ===")
    print(f"Windowed: {DIST_DIR / f'{APP_NAME}-gui'}")
    print(f"Console:  {DIST_DIR / f'{APP_NAME}-console'}")


def generate_spec():
    """Generate a PyInstaller spec file for custom builds."""
    spec_content = f"""# -*- mode: python ; coding: utf-8 -*-
# Scrcpy GamePad PyInstaller Spec File

block_cipher = None

a = Analysis(
    ['{PROJECT_ROOT / "main.py"}'],
    pathex=['{PROJECT_ROOT}'],
    binaries=[],
    datas=[
        ('{PROJECT_ROOT / "src" / "config"}', 'src/config'),
        ('{PROJECT_ROOT / "src" / "core"}', 'src/core'),
        ('{PROJECT_ROOT / "src" / "gui"}', 'src/gui'),
    ],
    hiddenimports=[
        'PyQt6.QtWidgets', 'PyQt6.QtCore', 'PyQt6.QtGui',
        'src.core.adb_manager', 'src.core.touch_injector',
        'src.core.key_mapper', 'src.core.joystick_engine',
        'src.gui.main_window', 'src.gui.joystick_widget',
        'src.gui.key_editor_dialog', 'src.gui.screen_overlay',
        'src.config.settings', 'src.config.default_profiles',
    ],
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=['tkinter', 'matplotlib', 'numpy', 'scipy'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='{APP_NAME}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # Set True for console version
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='{APP_NAME}',
)
"""
    spec_path = PROJECT_ROOT / f"{APP_NAME}.spec"
    spec_path.write_text(spec_content)
    print(f"Spec file generated: {spec_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python build.py [clean|build|build-all|spec]")
        print("  clean      - Remove build artifacts")
        print("  build      - Build windowed version")
        print("  build-all  - Build both windowed and console versions")
        print("  spec       - Generate PyInstaller spec file")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "clean":
        clean()
    elif cmd == "build":
        build()
    elif cmd == "build-all":
        build_all()
    elif cmd == "spec":
        generate_spec()
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)
