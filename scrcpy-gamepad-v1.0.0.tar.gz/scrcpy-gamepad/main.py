#!/usr/bin/env python3
"""
Scrcpy GamePad - Android Game Controller
Main entry point.
"""

import sys
import os
import argparse
import logging
import signal
from pathlib import Path

# Ensure the project root is in the path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))


def setup_logging(verbose: bool = False):
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def check_single_instance():
    """Ensure only one instance is running using a lock file."""
    lock_path = Path.home() / ".scrcpy-gamepad" / "app.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        # Check if lock file exists and process is alive
        if lock_path.exists():
            try:
                pid = int(lock_path.read_text().strip())
                # Check if process is still running
                os.kill(pid, 0)
                # Process is running - another instance exists
                print(f"Another instance is already running (PID: {pid})")
                print("Close the existing instance or delete the lock file:")
                print(f"  {lock_path}")
                return False
            except (ProcessLookupError, ValueError):
                # Process not found or invalid PID - stale lock
                lock_path.unlink(missing_ok=True)
            except PermissionError:
                # Permission denied - process exists but we can't check it
                pass

        # Write our PID
        lock_path.write_text(str(os.getpid()))
        return True
    except OSError:
        return True  # If we can't create lock, proceed anyway


def cleanup_lock():
    """Remove the lock file on exit."""
    lock_path = Path.home() / ".scrcpy-gamepad" / "app.lock"
    lock_path.unlink(missing_ok=True)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Scrcpy GamePad - Android game controller mapping tool"
    )
    parser.add_argument(
        "--device", "-d",
        help="Device serial number or IP:port to connect to"
    )
    parser.add_argument(
        "--profile", "-p",
        help="Load a key mapping profile (JSON file or preset name)"
    )
    parser.add_argument(
        "--no-gui",
        action="store_true",
        help="Run in headless mode (no GUI)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    args = parser.parse_args()

    setup_logging(args.verbose)
    logger = logging.getLogger(__name__)

    # Check single instance
    if not check_single_instance():
        sys.exit(1)

    # Ensure cleanup on exit
    import atexit
    atexit.register(cleanup_lock)

    # Handle signals
    def signal_handler(sig, frame):
        logger.info("Received shutdown signal")
        cleanup_lock()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    if args.no_gui:
        # Headless mode - just connect and run
        logger.info("Running in headless mode")
        from src.core.adb_manager import ADBManager
        from src.config.settings import Settings

        settings = Settings()
        adb = ADBManager(settings.adb_path)

        if args.device:
            if not adb.connect(args.device):
                logger.error(f"Failed to connect to {args.device}")
                sys.exit(1)
        else:
            devices = adb.list_devices()
            if not devices:
                logger.error("No devices found")
                sys.exit(1)
            if not adb.connect(devices[0][0]):
                logger.error(f"Failed to connect to {devices[0][0]}")
                sys.exit(1)

        logger.info(f"Connected to {adb.device_serial}")
        logger.info("Headless mode - press Ctrl+C to exit")

        try:
            while True:
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            adb.disconnect()
            cleanup_lock()

    else:
        # GUI mode
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import Qt

        # High DPI support
        os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")

        app = QApplication(sys.argv)
        app.setApplicationName("Scrcpy GamePad")
        app.setOrganizationName("ScrcpyGamePad")

        # Apply dark theme
        from src.gui.main_window import DARK_THEME
        app.setStyleSheet(DARK_THEME)

        # Create and show main window
        from src.gui.main_window import MainWindow
        window = MainWindow()

        # Auto-connect if device specified
        if args.device:
            window._addr_input.setText(args.device)
            # Defer connection to after window is shown
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(500, window._connect_device)

        # Load profile if specified
        if args.profile:
            from src.core.key_mapper import KeyMapper
            from src.config.default_profiles import get_profile
            profile = get_profile(args.profile)
            if profile:
                window._mapper.load_from_dict(profile)
                window._update_mapping_list()
            elif os.path.exists(args.profile):
                window._mapper.load_profile(args.profile)
                window._update_mapping_list()

        window.show()

        logger.info("Scrcpy GamePad started")
        exit_code = app.exec()

        cleanup_lock()
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
