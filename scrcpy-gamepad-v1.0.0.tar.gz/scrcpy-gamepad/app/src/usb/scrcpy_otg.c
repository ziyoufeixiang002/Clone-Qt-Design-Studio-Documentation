#include "scrcpy_otg.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <SDL3/SDL.h>

#ifdef _WIN32
# include "adb/adb.h"
#endif
#include "events.h"
#include "screen.h"
#include "sdl_hints.h"
#include "usb/aoa_hid.h"
#include "usb/gamepad_aoa.h"
#include "usb/keyboard_aoa.h"
#include "usb/mouse_aoa.h"
#include "util/log.h"

struct scrcpy_otg {
    struct sc_usb usb;
    struct sc_aoa aoa;
    struct sc_keyboard_aoa keyboard;
    struct sc_mouse_aoa mouse;
    struct sc_gamepad_aoa gamepad;

    struct sc_screen screen;
};

static void
sc_usb_on_disconnected(struct sc_usb *usb, void *userdata) {
    (void) usb;
    (void) userdata;

    sc_push_event(SC_EVENT_DEVICE_DISCONNECTED);
}

static enum scrcpy_exit_code
event_loop(struct scrcpy_otg *s) {
    SDL_Event event;
    while (SDL_WaitEvent(&event)) {
        switch (event.type) {
            case SC_EVENT_DEVICE_DISCONNECTED:
                LOGW("Device disconnected");
                sc_screen_handle_event(&s->screen, &event);
                return SCRCPY_EXIT_DISCONNECTED;
            case SC_EVENT_AOA_OPEN_ERROR:
                LOGE("AOA open error");
                return SCRCPY_EXIT_FAILURE;
            case SDL_EVENT_QUIT:
                LOGD("User requested to quit");
                return SCRCPY_EXIT_SUCCESS;
            default:
                sc_screen_handle_event(&s->screen, &event);
                break;
        }
    }
    return SCRCPY_EXIT_FAILURE;
}

enum scrcpy_exit_code
scrcpy_otg(struct scrcpy_options *options) {
    static struct scrcpy_otg scrcpy_otg;
    struct scrcpy_otg *s = &scrcpy_otg;

    const char *serial = options->serial;

    sc_sdl_set_hints(options->render_driver, options->disable_screensaver);

    // Minimal SDL initialization
    if (!SDL_Init(SDL_INIT_EVENTS)) {
        LOGE("Could not initialize SDL: %s", SDL_GetError());
        return SCRCPY_EXIT_FAILURE;
    }

    if (options->gamepad_input_mode != SC_GAMEPAD_INPUT_MODE_DISABLED) {
        if (!SDL_Init(SDL_INIT_GAMEPAD)) {
            LOGE("Could not initialize SDL gamepad: %s", SDL_GetError());
            // Not fatal, keyboard/mouse should still work
        }
    }

    atexit(SDL_Quit);

    enum scrcpy_exit_code ret = SCRCPY_EXIT_FAILURE;

    struct sc_key_processor *kp = NULL;
    struct sc_mouse_processor *mp = NULL;
    struct sc_gamepad_processor *gp = NULL;
    bool usb_device_initialized = false;
    bool usb_connected = false;
    bool aoa_started = false;
    bool aoa_initialized = false;
    bool screen_initialized = false;
    bool disconnected = false;

#ifdef _WIN32
    // On Windows, only one process could open a USB device
    // <https://github.com/Genymobile/scrcpy/issues/2773>
    LOGI("Killing adb server (if any)...");
    if (sc_adb_init()) {
        unsigned flags = SC_ADB_NO_STDOUT | SC_ADB_NO_STDERR | SC_ADB_NO_LOGERR;
        // uninterruptible (intr == NULL), but in practice it's very quick
        sc_adb_kill_server(NULL, flags);
        sc_adb_destroy();
    } else {
        LOGW("Could not call adb executable, adb server not killed");
    }
#endif

    static const struct sc_usb_callbacks cbs = {
        .on_disconnected = sc_usb_on_disconnected,
    };
    bool ok = sc_usb_init(&s->usb);
    if (!ok) {
        return SCRCPY_EXIT_FAILURE;
    }

    struct sc_usb_device usb_device;
    ok = sc_usb_select_device(&s->usb, serial, &usb_device);
    if (!ok) {
        goto end;
    }

    usb_device_initialized = true;

    ok = sc_usb_connect(&s->usb, usb_device.device, &cbs, NULL);
    if (!ok) {
        goto end;
    }
    usb_connected = true;

    ok = sc_aoa_init(&s->aoa, &s->usb, NULL);
    if (!ok) {
        goto end;
    }
    aoa_initialized = true;

    assert(options->keyboard_input_mode == SC_KEYBOARD_INPUT_MODE_AOA
        || options->keyboard_input_mode == SC_KEYBOARD_INPUT_MODE_DISABLED);
    assert(options->mouse_input_mode == SC_MOUSE_INPUT_MODE_AOA
        || options->mouse_input_mode == SC_MOUSE_INPUT_MODE_DISABLED);
    assert(options->gamepad_input_mode == SC_GAMEPAD_INPUT_MODE_AOA
        || options->gamepad_input_mode == SC_GAMEPAD_INPUT_MODE_DISABLED);

    bool enable_keyboard =
        options->keyboard_input_mode == SC_KEYBOARD_INPUT_MODE_AOA;
    bool enable_mouse =
        options->mouse_input_mode == SC_MOUSE_INPUT_MODE_AOA;
    bool enable_gamepad =
        options->gamepad_input_mode == SC_GAMEPAD_INPUT_MODE_AOA;

    if (enable_keyboard) {
        ok = sc_keyboard_aoa_init(&s->keyboard, &s->aoa);
        if (!ok) {
            goto end;
        }
        kp = &s->keyboard.key_processor;
    }

    if (enable_mouse) {
        ok = sc_mouse_aoa_init(&s->mouse, &s->aoa);
        if (!ok) {
            goto end;
        }
        mp = &s->mouse.mouse_processor;
    }

    if (enable_gamepad) {
        sc_gamepad_aoa_init(&s->gamepad, &s->aoa);
        gp = &s->gamepad.gamepad_processor;
    }

    ok = sc_aoa_start(&s->aoa);
    if (!ok) {
        goto end;
    }
    aoa_started = true;

    const char *window_title = options->window_title;
    if (!window_title) {
        window_title = usb_device.product ? usb_device.product : "scrcpy";
    }

    struct sc_screen_params params = {
        .video = false,
        .camera = false,
        .controller = false,
        .fp = NULL,
        .kp = kp,
        .mp = mp,
        .gp = gp,
        .mouse_bindings = options->mouse_bindings,
        .legacy_paste = false,
        .clipboard_autosync = false,
        .shortcut_mods = options->shortcut_mods,
        .window_title = window_title,
        .always_on_top = options->always_on_top,
        .window_x = options->window_x,
        .window_y = options->window_y,
        .window_width = options->window_width,
        .window_height = options->window_height,
        .window_borderless = options->window_borderless,
        .orientation = SC_ORIENTATION_0,
        .mipmaps = options->mipmaps,
        .fullscreen = false,
        .start_fps_counter = false,
    };

    ok = sc_screen_init(&s->screen, &params);
    if (!ok) {
        goto end;
    }
    screen_initialized = true;

    // usb_device not needed anymore
    sc_usb_device_destroy(&usb_device);
    usb_device_initialized = false;

    ret = event_loop(s);
    disconnected = ret == SCRCPY_EXIT_DISCONNECTED;

end:
    if (aoa_started) {
        sc_aoa_stop(&s->aoa);
    }
    sc_usb_stop(&s->usb);

    if (screen_initialized) {
        sc_screen_interrupt(&s->screen);

        if (disconnected) {
            sc_screen_handle_disconnection(&s->screen);
        }
        LOGD("Quit...");

        // Close the window immediately
        sc_screen_hide_window(&s->screen);
    }

    if (mp) {
        sc_mouse_aoa_destroy(&s->mouse);
    }
    if (kp) {
        sc_keyboard_aoa_destroy(&s->keyboard);
    }
    if (gp) {
        sc_gamepad_aoa_destroy(&s->gamepad);
    }

    if (aoa_initialized) {
        sc_aoa_join(&s->aoa);
        sc_aoa_destroy(&s->aoa);
    }

    sc_usb_join(&s->usb);

    if (usb_connected) {
        sc_usb_disconnect(&s->usb);
    }

    if (usb_device_initialized) {
        sc_usb_device_destroy(&usb_device);
    }

    sc_usb_destroy(&s->usb);

    if (screen_initialized) {
        sc_screen_join(&s->screen);
        sc_screen_destroy(&s->screen);
    }

    return ret;
}
